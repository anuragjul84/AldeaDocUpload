﻿namespace ALU_AUTO_Uploading
{
    partial class FileBrowser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FileBrowser));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.ProjectWorkbook = new System.Windows.Forms.TreeView();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.expandAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SettingsButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Upload = new System.Windows.Forms.Button();
            this.Container1 = new System.Windows.Forms.SplitContainer();
            this.InternalUseOnlyChkBox = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.FileSummary = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CurrentRequestID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.FilesSelectionTab = new System.Windows.Forms.TabPage();
            this.UploadListTab = new System.Windows.Forms.TabPage();
            this.UploadListing = new System.Windows.Forms.DataGridView();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column0 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StatusLabel = new System.Windows.Forms.Label();
            this.PB = new System.Windows.Forms.ProgressBar();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fromTreeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fromTreeAndUploadListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeFromTreeAndUploadListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fromFolderAndUploadListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aLUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.contextMenuStrip2.SuspendLayout();
            this.Container1.Panel1.SuspendLayout();
            this.Container1.Panel2.SuspendLayout();
            this.Container1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.FilesSelectionTab.SuspendLayout();
            this.UploadListTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UploadListing)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "bullet4.fw.png");
            this.imageList1.Images.SetKeyName(1, "ico_txt.gif");
            this.imageList1.Images.SetKeyName(2, "bullet1.fw.png");
            this.imageList1.Images.SetKeyName(3, "bullet3.fw.png");
            // 
            // ProjectWorkbook
            // 
            this.ProjectWorkbook.AllowDrop = true;
            this.ProjectWorkbook.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ProjectWorkbook.ContextMenuStrip = this.contextMenuStrip2;
            this.ProjectWorkbook.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ProjectWorkbook.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.ProjectWorkbook.ImageIndex = 1;
            this.ProjectWorkbook.ImageList = this.imageList1;
            this.ProjectWorkbook.ItemHeight = 22;
            this.ProjectWorkbook.Location = new System.Drawing.Point(0, 0);
            this.ProjectWorkbook.Name = "ProjectWorkbook";
            this.ProjectWorkbook.SelectedImageIndex = 0;
            this.ProjectWorkbook.Size = new System.Drawing.Size(460, 251);
            this.ProjectWorkbook.TabIndex = 8;
            this.ProjectWorkbook.AfterCollapse += new System.Windows.Forms.TreeViewEventHandler(this.ProjectWorkbook_AfterCollapse);
            this.ProjectWorkbook.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.ProjectWorkbook_AfterExpand);
            this.ProjectWorkbook.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.ProjectWorkbook_AfterSelect);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.expandAllToolStripMenuItem,
            this.loadAccountToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip1";
            this.contextMenuStrip2.Size = new System.Drawing.Size(147, 48);
            // 
            // expandAllToolStripMenuItem
            // 
            this.expandAllToolStripMenuItem.Name = "expandAllToolStripMenuItem";
            this.expandAllToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.expandAllToolStripMenuItem.Text = "Expand all";
            this.expandAllToolStripMenuItem.Click += new System.EventHandler(this.expandAllToolStripMenuItem_Click);
            // 
            // loadAccountToolStripMenuItem
            // 
            this.loadAccountToolStripMenuItem.Name = "loadAccountToolStripMenuItem";
            this.loadAccountToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.loadAccountToolStripMenuItem.Text = "Load account";
            this.loadAccountToolStripMenuItem.Visible = false;
            this.loadAccountToolStripMenuItem.Click += new System.EventHandler(this.loadAccountToolStripMenuItem_Click);
            // 
            // SettingsButton
            // 
            this.SettingsButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(214)))));
            this.SettingsButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(184)))));
            this.SettingsButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(130)))), ((int)(((byte)(194)))));
            this.SettingsButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(160)))), ((int)(((byte)(224)))));
            this.SettingsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SettingsButton.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.SettingsButton.ForeColor = System.Drawing.Color.White;
            this.SettingsButton.Location = new System.Drawing.Point(128, 357);
            this.SettingsButton.Margin = new System.Windows.Forms.Padding(5);
            this.SettingsButton.Name = "SettingsButton";
            this.SettingsButton.Size = new System.Drawing.Size(77, 24);
            this.SettingsButton.TabIndex = 9;
            this.SettingsButton.Text = "Settings";
            this.SettingsButton.UseVisualStyleBackColor = false;
            this.SettingsButton.Click += new System.EventHandler(this.SettingsButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("HP Simplified Light", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(29, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 29);
            this.label2.TabIndex = 7;
            this.label2.Text = "Main";
            // 
            // Upload
            // 
            this.Upload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(214)))));
            this.Upload.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(184)))));
            this.Upload.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(130)))), ((int)(((byte)(194)))));
            this.Upload.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(160)))), ((int)(((byte)(224)))));
            this.Upload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Upload.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.Upload.ForeColor = System.Drawing.Color.White;
            this.Upload.Location = new System.Drawing.Point(34, 357);
            this.Upload.Margin = new System.Windows.Forms.Padding(5);
            this.Upload.Name = "Upload";
            this.Upload.Size = new System.Drawing.Size(84, 25);
            this.Upload.TabIndex = 9;
            this.Upload.Text = "Upload";
            this.Upload.UseVisualStyleBackColor = false;
            this.Upload.Click += new System.EventHandler(this.Upload_Click);
            // 
            // Container1
            // 
            this.Container1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Container1.IsSplitterFixed = true;
            this.Container1.Location = new System.Drawing.Point(3, 3);
            this.Container1.Name = "Container1";
            // 
            // Container1.Panel1
            // 
            this.Container1.Panel1.Controls.Add(this.ProjectWorkbook);
            // 
            // Container1.Panel2
            // 
            this.Container1.Panel2.BackColor = System.Drawing.Color.Transparent;
            this.Container1.Panel2.Controls.Add(this.InternalUseOnlyChkBox);
            this.Container1.Panel2.Controls.Add(this.label4);
            this.Container1.Panel2.Controls.Add(this.comboBox1);
            this.Container1.Panel2.Controls.Add(this.FileSummary);
            this.Container1.Panel2.Controls.Add(this.label1);
            this.Container1.Panel2.Controls.Add(this.CurrentRequestID);
            this.Container1.Panel2.Controls.Add(this.label3);
            this.Container1.Size = new System.Drawing.Size(639, 251);
            this.Container1.SplitterDistance = 460;
            this.Container1.TabIndex = 29;
            // 
            // InternalUseOnlyChkBox
            // 
            this.InternalUseOnlyChkBox.AutoSize = true;
            this.InternalUseOnlyChkBox.Location = new System.Drawing.Point(65, 212);
            this.InternalUseOnlyChkBox.Name = "InternalUseOnlyChkBox";
            this.InternalUseOnlyChkBox.Size = new System.Drawing.Size(107, 17);
            this.InternalUseOnlyChkBox.TabIndex = 33;
            this.InternalUseOnlyChkBox.Text = "Internal Use Only";
            this.InternalUseOnlyChkBox.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("HP Simplified", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(5, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 16);
            this.label4.TabIndex = 31;
            this.label4.Text = "Document Status";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(17, 185);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(155, 21);
            this.comboBox1.TabIndex = 30;
            // 
            // FileSummary
            // 
            this.FileSummary.BackColor = System.Drawing.Color.White;
            this.FileSummary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FileSummary.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.FileSummary.Location = new System.Drawing.Point(17, 72);
            this.FileSummary.Name = "FileSummary";
            this.FileSummary.Size = new System.Drawing.Size(155, 93);
            this.FileSummary.TabIndex = 29;
            this.FileSummary.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("HP Simplified", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(5, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 16);
            this.label1.TabIndex = 28;
            this.label1.Text = "FileSummary";
            // 
            // CurrentRequestID
            // 
            this.CurrentRequestID.BackColor = System.Drawing.Color.White;
            this.CurrentRequestID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CurrentRequestID.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.CurrentRequestID.Location = new System.Drawing.Point(17, 29);
            this.CurrentRequestID.Name = "CurrentRequestID";
            this.CurrentRequestID.Size = new System.Drawing.Size(155, 21);
            this.CurrentRequestID.TabIndex = 27;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("HP Simplified", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(5, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 16);
            this.label3.TabIndex = 25;
            this.label3.Text = "Aldea Request ID";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.FilesSelectionTab);
            this.tabControl1.Controls.Add(this.UploadListTab);
            this.tabControl1.Location = new System.Drawing.Point(34, 55);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(653, 283);
            this.tabControl1.TabIndex = 32;
            // 
            // FilesSelectionTab
            // 
            this.FilesSelectionTab.Controls.Add(this.Container1);
            this.FilesSelectionTab.Location = new System.Drawing.Point(4, 22);
            this.FilesSelectionTab.Name = "FilesSelectionTab";
            this.FilesSelectionTab.Padding = new System.Windows.Forms.Padding(3);
            this.FilesSelectionTab.Size = new System.Drawing.Size(645, 257);
            this.FilesSelectionTab.TabIndex = 0;
            this.FilesSelectionTab.Text = "Files Selection";
            this.FilesSelectionTab.UseVisualStyleBackColor = true;
            // 
            // UploadListTab
            // 
            this.UploadListTab.Controls.Add(this.UploadListing);
            this.UploadListTab.Location = new System.Drawing.Point(4, 22);
            this.UploadListTab.Name = "UploadListTab";
            this.UploadListTab.Padding = new System.Windows.Forms.Padding(3);
            this.UploadListTab.Size = new System.Drawing.Size(645, 257);
            this.UploadListTab.TabIndex = 1;
            this.UploadListTab.Text = "Upload List";
            this.UploadListTab.UseVisualStyleBackColor = true;
            // 
            // UploadListing
            // 
            this.UploadListing.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.UploadListing.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.UploadListing.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.UploadListing.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UploadListing.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7,
            this.Column0,
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column8,
            this.Column9});
            this.UploadListing.Dock = System.Windows.Forms.DockStyle.Fill;
            this.UploadListing.Location = new System.Drawing.Point(3, 3);
            this.UploadListing.Name = "UploadListing";
            this.UploadListing.RowHeadersWidth = 28;
            this.UploadListing.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.UploadListing.Size = new System.Drawing.Size(639, 251);
            this.UploadListing.TabIndex = 0;
            this.UploadListing.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.UploadListing_CellContentClick);
            this.UploadListing.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.UploadListing_UserDeletingRow);
            // 
            // Column7
            // 
            this.Column7.HeaderText = "File Name";
            this.Column7.Name = "Column7";
            // 
            // Column0
            // 
            this.Column0.HeaderText = "File Path";
            this.Column0.Name = "Column0";
            this.Column0.Width = 200;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Account";
            this.Column1.Name = "Column1";
            this.Column1.Width = 88;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Group Category";
            this.Column2.Name = "Column2";
            this.Column2.Width = 87;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Category";
            this.Column3.Name = "Column3";
            this.Column3.Width = 87;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Document Status";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            dataGridViewCellStyle2.Format = "N0";
            dataGridViewCellStyle2.NullValue = "0";
            this.Column5.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column5.HeaderText = "Request ID";
            this.Column5.Name = "Column5";
            this.Column5.Width = 88;
            // 
            // Column6
            // 
            this.Column6.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column6.HeaderText = "FileSummary";
            this.Column6.Name = "Column6";
            this.Column6.Width = 88;
            // 
            // Column8
            // 
            this.Column8.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column8.HeaderText = "State";
            this.Column8.Name = "Column8";
            this.Column8.Width = 88;
            // 
            // Column9
            // 
            this.Column9.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column9.HeaderText = "InternalUseOnly";
            this.Column9.Name = "Column9";
            this.Column9.Width = 88;
            // 
            // StatusLabel
            // 
            this.StatusLabel.BackColor = System.Drawing.Color.Transparent;
            this.StatusLabel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.StatusLabel.Font = new System.Drawing.Font("HP Simplified", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.StatusLabel.Location = new System.Drawing.Point(0, 428);
            this.StatusLabel.Name = "StatusLabel";
            this.StatusLabel.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.StatusLabel.Size = new System.Drawing.Size(711, 34);
            this.StatusLabel.TabIndex = 34;
            // 
            // PB
            // 
            this.PB.Location = new System.Drawing.Point(33, 406);
            this.PB.Name = "PB";
            this.PB.Size = new System.Drawing.Size(267, 10);
            this.PB.TabIndex = 36;
            this.PB.Visible = false;
            // 
            // CancelBtn
            // 
            this.CancelBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(214)))));
            this.CancelBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(184)))));
            this.CancelBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(130)))), ((int)(((byte)(194)))));
            this.CancelBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(160)))), ((int)(((byte)(224)))));
            this.CancelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CancelBtn.Font = new System.Drawing.Font("HP Simplified", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.CancelBtn.ForeColor = System.Drawing.Color.White;
            this.CancelBtn.Location = new System.Drawing.Point(215, 357);
            this.CancelBtn.Margin = new System.Windows.Forms.Padding(5);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(84, 25);
            this.CancelBtn.TabIndex = 37;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = false;
            this.CancelBtn.Visible = false;
            this.CancelBtn.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.removeFromTreeAndUploadListToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(164, 48);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fromTreeToolStripMenuItem,
            this.fromTreeAndUploadListToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(163, 22);
            this.toolStripMenuItem1.Text = "Remove selected";
            // 
            // fromTreeToolStripMenuItem
            // 
            this.fromTreeToolStripMenuItem.Name = "fromTreeToolStripMenuItem";
            this.fromTreeToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.fromTreeToolStripMenuItem.Text = "From folder";
            this.fromTreeToolStripMenuItem.Click += new System.EventHandler(this.fromTreeToolStripMenuItem_Click);
            // 
            // fromTreeAndUploadListToolStripMenuItem
            // 
            this.fromTreeAndUploadListToolStripMenuItem.Name = "fromTreeAndUploadListToolStripMenuItem";
            this.fromTreeAndUploadListToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.fromTreeAndUploadListToolStripMenuItem.Text = "From folder and upload list";
            this.fromTreeAndUploadListToolStripMenuItem.Click += new System.EventHandler(this.fromTreeAndUploadListToolStripMenuItem_Click);
            // 
            // removeFromTreeAndUploadListToolStripMenuItem
            // 
            this.removeFromTreeAndUploadListToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inFolderToolStripMenuItem,
            this.fromFolderAndUploadListToolStripMenuItem});
            this.removeFromTreeAndUploadListToolStripMenuItem.Name = "removeFromTreeAndUploadListToolStripMenuItem";
            this.removeFromTreeAndUploadListToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.removeFromTreeAndUploadListToolStripMenuItem.Text = "Remove all";
            this.removeFromTreeAndUploadListToolStripMenuItem.Click += new System.EventHandler(this.removeFromTreeAndUploadListToolStripMenuItem_Click);
            // 
            // inFolderToolStripMenuItem
            // 
            this.inFolderToolStripMenuItem.Name = "inFolderToolStripMenuItem";
            this.inFolderToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.inFolderToolStripMenuItem.Text = "From folder";
            // 
            // fromFolderAndUploadListToolStripMenuItem
            // 
            this.fromFolderAndUploadListToolStripMenuItem.Name = "fromFolderAndUploadListToolStripMenuItem";
            this.fromFolderAndUploadListToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.fromFolderAndUploadListToolStripMenuItem.Text = "From folder and upload list";
            this.fromFolderAndUploadListToolStripMenuItem.Click += new System.EventHandler(this.fromFolderAndUploadListToolStripMenuItem_Click);
            // 
            // aLUToolStripMenuItem
            // 
            this.aLUToolStripMenuItem.Checked = true;
            this.aLUToolStripMenuItem.CheckOnClick = true;
            this.aLUToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.aLUToolStripMenuItem.Name = "aLUToolStripMenuItem";
            this.aLUToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.aLUToolStripMenuItem.Text = "ALU";
            // 
            // eONToolStripMenuItem
            // 
            this.eONToolStripMenuItem.Checked = true;
            this.eONToolStripMenuItem.CheckOnClick = true;
            this.eONToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.eONToolStripMenuItem.Name = "eONToolStripMenuItem";
            this.eONToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.eONToolStripMenuItem.Text = "EON";
            // 
            // refreshToolStripMenuItem1
            // 
            this.refreshToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aLUToolStripMenuItem,
            this.eONToolStripMenuItem});
            this.refreshToolStripMenuItem1.Name = "refreshToolStripMenuItem1";
            this.refreshToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.refreshToolStripMenuItem1.Text = "Account";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(574, 38);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 38;
            this.button1.Text = "Clear List";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FileBrowser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 462);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.PB);
            this.Controls.Add(this.StatusLabel);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.SettingsButton);
            this.Controls.Add(this.Upload);
            this.Controls.Add(this.label2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(400, 450);
            this.Name = "FileBrowser";
            this.Text = "Aldea Upload";
            this.Load += new System.EventHandler(this.FileBrowser_Load);
            this.Shown += new System.EventHandler(this.FileBrowser_Shown);
            this.ResizeEnd += new System.EventHandler(this.FileBrowser_ResizeEnd);
            this.Resize += new System.EventHandler(this.FileBrowser_Resize);
            this.contextMenuStrip2.ResumeLayout(false);
            this.Container1.Panel1.ResumeLayout(false);
            this.Container1.Panel2.ResumeLayout(false);
            this.Container1.Panel2.PerformLayout();
            this.Container1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.FilesSelectionTab.ResumeLayout(false);
            this.UploadListTab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.UploadListing)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TreeView ProjectWorkbook;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button SettingsButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Upload;
        private System.Windows.Forms.SplitContainer Container1;
        private System.Windows.Forms.TextBox CurrentRequestID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage FilesSelectionTab;
        private System.Windows.Forms.TabPage UploadListTab;
        private System.Windows.Forms.DataGridView UploadListing;
        private System.Windows.Forms.Label StatusLabel;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ProgressBar PB;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column0;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.ToolStripMenuItem expandAllToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem removeFromTreeAndUploadListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fromTreeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fromTreeAndUploadListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inFolderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fromFolderAndUploadListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aLUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem loadAccountToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox FileSummary;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.CheckBox InternalUseOnlyChkBox;
        private System.Windows.Forms.Button button1;
    }
}