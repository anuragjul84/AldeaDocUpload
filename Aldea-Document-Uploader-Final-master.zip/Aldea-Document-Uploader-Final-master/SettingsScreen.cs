﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ALU_AUTO_Uploading
{
    public partial class SettingsScreen : Form
    {
        public SettingsScreen()
        {
            InitializeComponent();
        }
        private void SettingsScreen_Load(object sender, EventArgs e)
        {
            UserEmail.Text = Properties.Settings.Default.UserEmail;
            //UserNT.Text = Properties.Settings.Default.UserNT;
            UserPassword.Text = Properties.Settings.Default.UserPassword;
            UserAldeaPrefix.Text = Properties.Settings.Default.UserAldeaPrefix;
            EnableTestMode.Checked = Properties.Settings.Default.UserTestMode;
            DisplayDropAlerts.Checked = Properties.Settings.Default.UserDisplayDropAlerts;
            UserRegion.Text = Properties.Settings.Default.UserRegion;
            UserRegion.Items.Add("AMS");
            //UserRegion.Items.Add("AMS-R");
            UserRegion.Items.Add("APJ");            
            UserRegion.Items.Add("EU");
            UserRegion.Items.Add("EUC");
            UserRegion.Items.Add("MONDELEZ");
            //UserRegion.Items.Add("UKI-R");
        }

        private void ButtonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void ButtonApply_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.UserEmail = UserEmail.Text;
            //Properties.Settings.Default.UserNT = UserNT.Text;
            Properties.Settings.Default.UserPassword = UserPassword.Text;
            Properties.Settings.Default.UserAldeaPrefix = UserAldeaPrefix.Text;
            Properties.Settings.Default.UserTestMode = EnableTestMode.Checked;
            Properties.Settings.Default.UserDisplayDropAlerts = DisplayDropAlerts.Checked;
            Properties.Settings.Default.UserRegion = UserRegion.Text;
            Properties.Settings.Default.Save();
            MessageBox.Show("The settings were successfully saved.");
            this.Close();
        }

        private void OpenHistory_Click(object sender, EventArgs e)
        {
            HistoryViewer popup = new HistoryViewer();
            popup.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (UserRegion.Text=="AMS")
            {
                UserAldeaPrefix.Text = "https://am.svcs.entsvcs.net/aldea/";
            }
            else if (UserRegion.Text == "AMS-R")
            {
                UserAldeaPrefix.Text = "https://esm.lvg.dcs-usps.com/aldea/";
            }
            else if (UserRegion.Text == "APJ")
            {
                UserAldeaPrefix.Text = "https://ap.svcs.entsvcs.net/aldea/";
            }
            else if (UserRegion.Text == "EU")
            {
                UserAldeaPrefix.Text = "https://eu.svcs.entsvcs.net/aldea/";
            }
            else if (UserRegion.Text == "EUC")
            {
                UserAldeaPrefix.Text = "https://euc-p.svcs.entsvcs.com/eu_aldea/";
            }
            else if (UserRegion.Text == "MONDELEZ")
            {
                UserAldeaPrefix.Text = "https://am.svcs.entsvcs.net/aldea/consumer/";
            }
            else if (UserRegion.Text == "UKI-R")
            {
                UserAldeaPrefix.Text = "https://ukon.ukofficialnet.gbr.hpecorp.net/aldea/";
            }
        }
    }
}
