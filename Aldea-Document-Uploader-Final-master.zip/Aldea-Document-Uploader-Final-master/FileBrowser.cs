﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Diagnostics;
using System.Threading;
using System.Collections;
using ALU_AUTO_Uploading;

namespace ALU_AUTO_Uploading
{
    public partial class FileBrowser : Form
    {

        //public List<TreeNode> SelectedLocal = new List<TreeNode>();
        //public List<TreeNode> SelectedWorkbook = new List<TreeNode>();
        public XmlDocument UploadListTemporary = new XmlDocument();
        public XmlDocument UploadList = new XmlDocument();
        public int filesNumber = 0;
        public Thread work_AllFolders;
        public string filePath = "";
        public string threadProgress = "";
        public Boolean threadChange = false;
        public int filesCounter = 0;
        public string historyLog = "";
        public Boolean begunRequestProcessing = false;
        public Boolean performStep = false;
        public Boolean DocumentLoaded = false;
        public int nooftimes;
        public string PrevrequestID = "";
        public Boolean RecordFound;

        /// /////////
        //  FUNCTIONS
        /// /////////

        public FileBrowser()
        {
            InitializeComponent();
        }

        private void HistoryBtn_Click(object sender, EventArgs e)
        {
            HistoryViewer settings = new HistoryViewer();
            settings.ShowDialog();
        }
        private void FileBrowser_Load(object sender, EventArgs e)
        {

            Properties.Settings.Default.LocalWorkbooks = "<settings><structure name='Aldea Project Workbooks'><group name='Requirements / Solution Build Folders'><category name='Datacenter Hosting Request Form' id='1418' color='BLUE'/><category name='Requirements Forms' id='1420' color='RED'/><category name='Solution Design Documents' id='1421' color='BLUE'/><category name='Internal Request Forms' id='1419' color='BLUE'/></group><group name='Contract Change Assessment Folder'><category name='Contract Change Assessment' id='1399' color='BLUE'/></group><group name='Costing Folders'><category name='Client Costing' id='1402' color='BLUE'/><category name='Internal Billing' id='1403' color='BLUE'/><category name='Asset Management Documentation' id='1401' color='BLUE'/></group><group name='Pricing Folder'><category name='Client Pricing' id='1411' color='BLUE'/></group><group name='Quote Folders'><category name='Estimate / Quote Delivery Documents' id='1415' color='RED'/><category name='Revenue / Expense Outlook' id='1416' color='BLUE'/><category name='Draft Quote' id='1876' color='BLUE'/></group><group name='Quote Approval Letters'><category name='Client Estimate / Quote Approval Letters' id='1413' color='RED'/></group><group name='Implementation Folder'><category name='Project Plan' id='1409' color='RED'/><category name='Implementation Internal Documents' id='1875' color='BLUE'/></group><group name='User Acceptance Folder'><category name='Client Accpt Of Goods &amp; Svcs Notifications' id='1423' color='RED'/></group><group name='General Folders'><category name='General Communications' id='1406' color='RED'/><category name='Client Documents' id='1405' color='RED'/><category name='Issues and Disputes' id='1407' color='BLUE'/></group></structure></settings>";
            //Properties.Settings.Default.LocalWorkbooks = "<settings><structure name='Aldea Project Workbooks'><group name='Requirements / Solution Build Folders'><category name='Datacenter Hosting Request Form' id='1418' color='BLUE'/><category name='Requirements Forms' id='1420' color='BLUE'/><category name='Solution Design Documents' id='1421' color='BLUE'/><category name='Internal Request Forms' id='1419' color='BLUE'/></group><group name='Contract Change Assessment Folder'><category name='Contract Change Assessment' id='1399' color='BLUE'/></group><group name='Costing Folders'><category name='Client Costing' id='1402' color='BLUE'/><category name='Internal Billing' id='1403' color='BLUE'/><category name='Asset Management Documentation' id='1401' color='BLUE'/></group><group name='Pricing Folder'><category name='Client Pricing' id='1411' color='BLUE'/></group><group name='Quote Folders'><category name='Estimate / Quote Delivery Documents' id='1415' color='BLUE'/><category name='Revenue / Expense Outlook' id='1416' color='BLUE'/><category name='Draft Quote' id='1876' color='BLUE'/></group><group name='Quote Approval Letters'><category name='Client Estimate / Quote Approval Letters' id='1413' color='BLUE'/></group><group name='Implementation Folder'><category name='Project Plan' id='1409' color='BLUE'/><category name='Implementation Internal Documents' id='1875' color='BLUE'/></group><group name='User Acceptance Folder'><category name='Client Accpt Of Goods &amp; Svcs Notifications' id='1423' color='BLUE'/></group><group name='General Folders'><category name='General Communications' id='1406' color='BLUE'/><category name='Client Documents' id='1405' color='BLUE'/><category name='Issues and Disputes' id='1407' color='BLUE'/></group></structure></settings>";
            Properties.Settings.Default.Save();

            UpdateWorkbook();

            this.Width = Properties.Settings.Default.UserWindowWidth;
            this.Height = Properties.Settings.Default.UserWindowHeight;
            this.ProjectWorkbook.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.treeView_ItemDrag);
            //this.LocalFolders.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.treeView_ItemDrag);
            this.ProjectWorkbook.DragEnter += new System.Windows.Forms.DragEventHandler(this.treeView_DragEnter);
            //this.LocalFolders.DragEnter += new System.Windows.Forms.DragEventHandler(this.treeView_DragEnter);
            this.ProjectWorkbook.DragDrop += new System.Windows.Forms.DragEventHandler(this.treeView_DragDrop);
            //this.LocalFolders.DragDrop += new System.Windows.Forms.DragEventHandler(this.treeView_DragDrop);

            tabControl1.Width = this.ClientSize.Width - 60;
            Container1.SplitterDistance = tabControl1.Width - 190;
            tabControl1.Height = this.ClientSize.Height - 150;
            Upload.Top = this.ClientSize.Height - 60;
            SettingsButton.Top = this.ClientSize.Height - 60;
            CancelBtn.Top = this.ClientSize.Height - 60;
            // initialize public vars
            UploadListTemporary.LoadXml("<items></items>");
            UploadList.LoadXml("<UPLOAD></UPLOAD>");
            comboBox1.Items.Add("Final");
            comboBox1.Items.Add("Public Draft");
        }
        private void FileBrowser_Shown(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.LocalLastBrowse != "")
            {
                SetStatus("Loading directory structure", true, ProgressBarStyle.Marquee);
                //ListDirectory(LocalFolders, Properties.Settings.Default.LocalLastBrowse);
                //if (isNumeric(new DirectoryInfo(Properties.Settings.Default.LocalLastBrowse).Name))
                //{
                //    CurrentRequestID.Text = LocalFolders.Nodes[0].Text;
                //}
                SetStatus("");
            }
        }
        private void FileBrowser_Resize(object sender, EventArgs e)
        {
            //Container1.Width = this.ClientSize.Width - 48;
            try
            {
                tabControl1.Width = this.ClientSize.Width - 60;
                Container1.SplitterDistance = tabControl1.Width - 190;
                tabControl1.Height = this.ClientSize.Height - 150;
                Upload.Top = this.ClientSize.Height - 60;
                SettingsButton.Top = this.ClientSize.Height - 60;
                PB.Top = this.ClientSize.Height - 15;
                CancelBtn.Top = this.ClientSize.Height - 60;
            }
            catch (Exception exc)
            {
            }
        }
        private void UpdateWorkbook()
        {
            ProjectWorkbook.Nodes.Clear();
            XmlDocument LocalWorkbooks = new XmlDocument();
            if (Properties.Settings.Default.LocalWorkbooks != "")
            {
                LocalWorkbooks.LoadXml(Properties.Settings.Default.LocalWorkbooks);
                TreeNode nodeStructure;
                TreeNode nodeGroup;
                TreeNode nodeCategory;

                foreach (XmlElement structure in LocalWorkbooks.GetElementsByTagName("structure"))
                {
                    //if (structure.GetAttribute("visible") != "TRUE")
                    //{
                    //    if (structure.GetAttribute("name") == "ALU Account") aLUToolStripMenuItem.Checked = false;
                    //    if (structure.GetAttribute("name") == "EON Account") eONToolStripMenuItem.Checked = false;
                    //    continue;
                    //} 
                    nodeStructure = new TreeNode();
                    nodeStructure.NodeFont = new Font("Verdana", 13, FontStyle.Underline, GraphicsUnit.Pixel);
                    nodeStructure.ForeColor = Color.Blue;
                    nodeStructure.Text = structure.GetAttribute("name");
                    nodeStructure.ImageIndex = 3;
                    nodeStructure.SelectedImageIndex = 3;
                    ProjectWorkbook.Nodes.Add(nodeStructure);

                    foreach (XmlElement group in structure.GetElementsByTagName("group"))
                    {
                        nodeGroup = new TreeNode();
                        nodeGroup.NodeFont = new Font("Verdana", 12, FontStyle.Bold, GraphicsUnit.Pixel);

                        nodeGroup.ForeColor = Color.Black;
                        nodeGroup.Text = group.GetAttribute("name");
                        nodeGroup.ImageIndex = 2;

                        nodeGroup.SelectedImageIndex = 2;
                        nodeStructure.Nodes.Add(nodeGroup);

                        foreach (XmlElement category in group.GetElementsByTagName("category"))
                        {
                            nodeCategory = new TreeNode();
                            nodeCategory.NodeFont = new Font("Verdana", 12, FontStyle.Underline, GraphicsUnit.Pixel);
                            nodeCategory.ImageIndex = 1;
                            nodeCategory.SelectedImageIndex = 1;
                            nodeCategory.Text = category.GetAttribute("name") + " (0)";

                            if (category.GetAttribute("color") == "RED")
                            {
                                nodeCategory.ForeColor = Color.Red;
                            }
                            else
                            {
                                nodeCategory.ForeColor = Color.Blue;
                            }
                            nodeGroup.Nodes.Add(nodeCategory);
                        }
                        if (group.HasAttribute("expanded"))
                        {
                            if (group.GetAttribute("expanded") == "YES")
                            {
                                nodeGroup.Expand();
                            }
                        }
                    }
                    if (structure.HasAttribute("expanded"))
                    {
                        if (structure.GetAttribute("expanded") == "YES")
                        {
                            nodeStructure.Expand();
                        }
                    }
                }
            }
        }
        private void treeView_ItemDrag(object sender, System.Windows.Forms.ItemDragEventArgs e)
        {
            DoDragDrop(e.Item, DragDropEffects.Move);

        }
        private void treeView_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }
        private void treeView_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
        {
            // SET INNER VARS
            TreeNode AddedRow;
            string tempXmlNode = "";
            string PrevWindowsFile = "";
            TreeNode rootFinder = new TreeNode();
            FileInfo WindowsFile = null;
            string[] innerhtmlfile = new string[50];
            int i;
            //Array.Clear(innerhtmlfile, 0, 49);

            // CHECK IF THE DRAG WAS INITIATED FROM A WINDOWS EXPLORER -> FILE ITEM
            if (e.Data.GetDataPresent(DataFormats.FileDrop, false))
            {
                Point pt = ((TreeView)sender).PointToClient(new Point(e.X, e.Y));
                TreeNode DestinationNode = ((TreeView)sender).GetNodeAt(pt);
                // CHECK IF THE DESTINATION NODE IS A CATEGORY NODE
                if (DestinationNode.Level == 2)
                {
                    // GET ALL THE FILES IN FROM THE DRAG-DROP EVENT
                    string[] l_fileSystemObjects = (string[])(e.Data.GetData(DataFormats.FileDrop, false));
                    foreach (string l_fileSystemObject in l_fileSystemObjects)
                    {
                        // SET FILE PATH TO A TEMP FILE_INFO OBJECT
                        WindowsFile = new FileInfo(l_fileSystemObject);
                        if (PrevWindowsFile == WindowsFile.FullName)
                        {
                            return;
                        }
                        if (Convert.ToDecimal(WindowsFile.Length / 1000000) > 20)
                        {
                            if (MessageBox.Show(WindowsFile.Name + " size of " + Convert.ToDecimal(WindowsFile.Length / 1000000).ToString() + "MB exceeds the 20MB limit.\nMost likely the upload will fail.\nProceed anyway?", "File size exceeds limit", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != System.Windows.Forms.DialogResult.Yes)
                            {
                                continue;
                            }
                        }

                        //CheckUploadList();

                        //if (RecordFound == false)
                        //{
                        // CREATE NEW TREE NODE
                        AddedRow = new TreeNode();

                        // ADD THE ROW IN THE CATEGORY NODE
                        DestinationNode.Nodes.Add(AddedRow);
                        // EXPAND THE CATEGORY NODE
                        DestinationNode.Expand();
                        // SET IMAGE FOR THE NEW NODE (DOCUMENT ICON)
                        AddedRow.ImageIndex = 1;
                        AddedRow.SelectedImageIndex = 1;
                        // SET TEXT FOR THE NEW NODE
                        AddedRow.Text = WindowsFile.Name;
                        // SET FONT
                        AddedRow.NodeFont = new Font(ProjectWorkbook.Font, FontStyle.Regular);
                        // SET CONTEXT MENU
                        AddedRow.ContextMenuStrip = contextMenuStrip1;
                        // COUNT ITEMS UNDER CATEGORY NODE
                        if (DestinationNode.Text.Contains("("))
                        {
                            DestinationNode.Text = DestinationNode.Text.Substring(0, DestinationNode.Text.IndexOf("(")) + "(" + DestinationNode.Nodes.Count.ToString() + ")";
                        }
                        else
                        {
                            DestinationNode.Text = DestinationNode.Text + " (1)";
                        }
                        PrevWindowsFile = WindowsFile.FullName;

                        // CREATE TEMPORARY XML NODE (AS STRING)
                        tempXmlNode = "<item name='" + WindowsFile.Name.Replace("&", "&amp;") + "' path='" + WindowsFile.FullName.Replace("&", "&amp;") + "' category='" + DestinationNode.Text.Replace("&", "&amp;") + "' group='" + DestinationNode.Parent.Text + "' account='" + DestinationNode.Parent.Parent.Text + "' status='" + DestinationNode.ForeColor.ToString().Replace("Color [Red]", "Final").Replace("Color [Blue]", "Public Draft") + "'/>";
                        // ADD NODE TO THE TEMPORARY XML HOLDER

                        //for (i=0; i<innerhtmlfile.Length; i++)
                        //{
                        //  Console.WriteLine(innerhtmlfile[i]);
                        //MessageBox.Show(innerhtmlfile[i]); 
                        //if (innerhtmlfile[i] != null)
                        //{
                        //  if (innerhtmlfile[i] == tempXmlNode)
                        //{
                        //  goto next2;
                        //}
                        //}
                        //else
                        //{ 
                        //  innerhtmlfile[i] = tempXmlNode;
                        //goto next1;
                        //}
                        //}
                        //next1:
                        UploadListTemporary.DocumentElement.InnerXml = UploadListTemporary.DocumentElement.InnerXml + tempXmlNode;

                        // TRY TO FIND A PARENT FOLDER THAT IS A NUMERIC VALUE -> POSSIBLY THE REQUEST ID
                        //MessageBox.Show(WindowsFile.Directory.Parent.Parent.Parent.Parent.Name);
                        try
                        {
                            if (isNumeric(WindowsFile.Directory.Name))
                            {
                                CurrentRequestID.Text = WindowsFile.Directory.Name;
                            }
                            else if (isNumeric(WindowsFile.Directory.Parent.Name))
                            {
                                CurrentRequestID.Text = WindowsFile.Directory.Parent.Name;
                            }
                            else if (isNumeric(WindowsFile.Directory.Parent.Parent.Name))
                            {
                                CurrentRequestID.Text = WindowsFile.Directory.Parent.Parent.Name;
                            }
                            else if (isNumeric(WindowsFile.Directory.Parent.Parent.Parent.Name))
                            {
                                CurrentRequestID.Text = WindowsFile.Directory.Parent.Parent.Parent.Name;
                            }
                            //else if (isNumeric(WindowsFile.Directory.Parent.Parent.Parent.Parent.Name))
                            //{
                            //  CurrentRequestID.Text = WindowsFile.Directory.Parent.Parent.Parent.Parent.Name;
                            //}
                        }
                        catch (Exception exc)
                        {

                        }
                    }
                    // IF PROPERTY ENABLED, DISPLAY ALERT AFTER DROP ACTION
                    //if(Properties.Settings.Default.UserDisplayDropAlerts) MessageBox.Show("File(s) added to upload list");
                    // COPY DATA TO UPLOAD LIST
                    AddToUploadList();
                    //next2:
                    //                  i = 0;
                    //}
                }
            }
        }
        private static void ListDirectory(TreeView treeView, string path)
        {
            treeView.Nodes.Clear();

            var stack = new Stack<TreeNode>();
            var rootDirectory = new DirectoryInfo(path);
            var node = new TreeNode(rootDirectory.Name) { Tag = rootDirectory };
            stack.Push(node);
            TreeNode FileNode;

            while (stack.Count > 0)
            {
                Application.DoEvents();
                var currentNode = stack.Pop();
                var directoryInfo = (DirectoryInfo)currentNode.Tag;
                try
                {
                    foreach (var directory in directoryInfo.GetDirectories())
                    {
                        Application.DoEvents();
                        var childDirectoryNode = new TreeNode(directory.Name) { Tag = directory };
                        currentNode.Nodes.Add(childDirectoryNode);
                        stack.Push(childDirectoryNode);
                    }
                }
                catch (Exception e)
                {
                }
                try
                {
                    foreach (var file in directoryInfo.GetFiles())
                    {
                        Application.DoEvents();
                        FileNode = new TreeNode(file.Name);
                        FileNode.ForeColor = Color.Black;
                        FileNode.NodeFont = new Font(treeView.Font, FontStyle.Underline);
                        FileNode.ImageIndex = 1;
                        FileNode.SelectedImageIndex = 1;
                        currentNode.Nodes.Add(FileNode);
                    }
                }
                catch (Exception e)
                {
                }
            }

            treeView.Nodes.Add(node);
            Properties.Settings.Default.LocalLastBrowse = path;
            Properties.Settings.Default.Save();
        }
        private void RemoveFile_Click(object sender, EventArgs e)
        {
            if (ProjectWorkbook.SelectedNode.Level == 3)
            {
                foreach (XmlElement xmlObj in UploadListTemporary.DocumentElement.GetElementsByTagName("item"))
                {
                    if (xmlObj.GetAttribute("name") == ProjectWorkbook.SelectedNode.Text && xmlObj.GetAttribute("category") == ProjectWorkbook.SelectedNode.Parent.Text && xmlObj.GetAttribute("group") == ProjectWorkbook.SelectedNode.Parent.Parent.Text && xmlObj.GetAttribute("account") == ProjectWorkbook.SelectedNode.Parent.Parent.Parent.Text)
                    {

                        UploadListTemporary.DocumentElement.RemoveChild(xmlObj);
                        break;
                    }
                }
                ProjectWorkbook.SelectedNode.Parent.Text = ProjectWorkbook.SelectedNode.Parent.Text.Substring(0, ProjectWorkbook.SelectedNode.Parent.Text.IndexOf("(")) + "(" + (ProjectWorkbook.SelectedNode.Parent.Nodes.Count - 1).ToString() + ")";
                ProjectWorkbook.Nodes.Remove(ProjectWorkbook.SelectedNode);
            }
        }
        //private void ProjectWorkbook_AfterSelect(object sender, TreeViewEventArgs e)
        //{
        //    if (ProjectWorkbook.SelectedNode.Level == 3)
        //    {
        //        RemoveFile.Enabled = true;
        //    } else {
        //        RemoveFile.Enabled = false;
        //    }
        //}
        private void SettingsButton_Click(object sender, EventArgs e)
        {
            SettingsScreen settings = new SettingsScreen();
            settings.ShowDialog();
        }
        private void FileBrowser_ResizeEnd(object sender, EventArgs e)
        {
            Properties.Settings.Default.UserWindowWidth = this.Width;
            Properties.Settings.Default.UserWindowHeight = this.Height;
            Properties.Settings.Default.Save();
        }
        //private void Container2_SplitterMoved(object sender, SplitterEventArgs e)
        //{
        //    Properties.Settings.Default.UserLayoutSplitter = Container2.SplitterDistance;
        //    Properties.Settings.Default.Save();
        //}
        private void getLocalFolderStructure()
        {

            UploadList = new XmlDocument();
            string requestFolder = "";
            string groupFolder = "";
            string singleFolder = "";

            UploadList.LoadXml("<local></local>");
            DirectoryInfo rootFolder = new DirectoryInfo(Properties.Settings.Default.UserLocalFolder);
            filesNumber = 0;

            foreach (TreeNode NodeAccount in ProjectWorkbook.Nodes)
            {

            }


            foreach (DirectoryInfo requestsFolder in rootFolder.GetDirectories())
            {
                Application.DoEvents();
                requestFolder += "<requestFolder name='" + requestsFolder.Name + "'>";
                groupFolder = "";
                foreach (DirectoryInfo groupsFolder in requestsFolder.GetDirectories())
                {
                    groupFolder += "<groupFolder name='" + groupsFolder.Name.Replace("%26", "&") + "'>";
                    singleFolder = "";
                    foreach (DirectoryInfo singlesFolder in groupsFolder.GetDirectories())
                    {
                        singleFolder += "<singleFolder name='" + singlesFolder.Name.Replace("%26", "&") + "'>";

                        foreach (FileInfo file in singlesFolder.GetFiles())
                        {
                            singleFolder += "<file name='" + file.Name.Replace("%26", "&") + "'/>";
                            filesNumber = filesNumber + 1;
                        }
                        singleFolder += "</singleFolder>";
                    }
                    groupFolder += singleFolder;
                    groupFolder += "</groupFolder>";
                }

                requestFolder += groupFolder + "</requestFolder>";

            }
            //localFolders.DocumentElement.InnerXml = requestFolder;
            // Properties.Settings.Default.LocalFolderStructure = localFolders.DocumentElement.OuterXml;
        }
        //private void BrowseForFolder_Click(object sender, EventArgs e)
        //{
        //    FolderBrowserDialog OpenFolder = new FolderBrowserDialog();
        //    try
        //    {
        //        OpenFolder.SelectedPath = Properties.Settings.Default.LocalLastBrowse;
        //    }
        //    catch (Exception exc)
        //    {

        //    }
        //    if (OpenFolder.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        //    {
        //        SetStatus("Loading directory structure", true, ProgressBarStyle.Marquee);

        //        ListDirectory(LocalFolders, OpenFolder.SelectedPath);
        //        SetStatus("");
        //        if (isNumeric(new DirectoryInfo(OpenFolder.SelectedPath).Name))
        //        {
        //            CurrentRequestID.Text = LocalFolders.Nodes[0].Text;
        //        }
        //        else
        //        {
        //            CurrentRequestID.Text = "";
        //        }
        //        Properties.Settings.Default.UserLocalFolder = OpenFolder.SelectedPath;
        //        Properties.Settings.Default.Save();
        //    }
        //    OpenFolder = null;
        //}
        private Boolean isNumeric(string StringObject)
        {
            double myNum = 0;

            if (Double.TryParse(StringObject, out myNum))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //private void clearAllToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    LocalFolders.Nodes.Clear();
        //    Properties.Settings.Default.LocalLastBrowse = "";
        //}
        //private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    if (Properties.Settings.Default.LocalLastBrowse != "")
        //    {
        //        StatusLabel.Text = "Loading...";
        //        ListDirectory(LocalFolders, Properties.Settings.Default.LocalLastBrowse);
        //        StatusLabel.Text = "Pending";
        //    }
        //}
        //private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    if (tabControl1.SelectedIndex > 0)
        //    {
        //        BrowseForFolder.Visible = false;
        //    }
        //    else
        //    {
        //        BrowseForFolder.Visible = true;
        //    }
        //}

        private void CheckUploadList()
        {
            String FileNAME = "", FilePATH = "", ACCOUNT = "", GroupCATEGORY = "", CATEGORY = "", DocumentSTATUS = "", FileSUMMARY1 = "", STATE = "";
            String RequestID = "";
            Boolean InternalUSEONLY;
            RecordFound = false;

            foreach (XmlElement tempUploadNode in UploadListTemporary.DocumentElement.GetElementsByTagName("item"))
            {
                foreach (DataGridViewRow row in UploadListing.Rows)
                {
                    if (row.Cells[0].Value != null)
                    {
                        FileNAME = row.Cells[0].Value.ToString();
                        FilePATH = row.Cells[1].Value.ToString();
                        ACCOUNT = row.Cells[2].Value.ToString();
                        GroupCATEGORY = row.Cells[3].Value.ToString();
                        CATEGORY = row.Cells[4].Value.ToString();
                        DocumentSTATUS = row.Cells[5].Value.ToString();
                        RequestID = row.Cells[6].Value.ToString();
                        FileSUMMARY1 = row.Cells[7].Value.ToString();
                        STATE = row.Cells[8].Value.ToString();
                        InternalUSEONLY = Convert.ToBoolean(row.Cells[9].Value);

                        if (FileNAME == tempUploadNode.GetAttribute("name"))
                        {
                            if (FilePATH == tempUploadNode.GetAttribute("path"))
                            {
                                if (ACCOUNT == tempUploadNode.GetAttribute("account"))
                                {
                                    if (GroupCATEGORY == tempUploadNode.GetAttribute("group"))
                                    {
                                        //if (CATEGORY == tempUploadNode.GetAttribute("category"))
                                        //{
                                        if (CATEGORY == tempUploadNode.GetAttribute("category").Substring(0, tempUploadNode.GetAttribute("category").LastIndexOf("(") - 1))
                                        {
                                            if (DocumentSTATUS == tempUploadNode.GetAttribute("status"))
                                            {
                                                if (RequestID == CurrentRequestID.Text)
                                                {
                                                    if (FileSUMMARY1 == FileSummary.Text)
                                                    {
                                                        if (STATE == comboBox1.Text)
                                                        {
                                                            if (InternalUSEONLY == InternalUseOnlyChkBox.Checked)
                                                            {
                                                                RecordFound = true;
                                                                return;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        //}
                                    }
                                }
                            }
                        }
                    }
                }
            //    UploadListing.Rows.Add(tempUploadNode.GetAttribute("name"), tempUploadNode.GetAttribute("path"), tempUploadNode.GetAttribute("account"), tempUploadNode.GetAttribute("group"), tempUploadNode.GetAttribute("category").Substring(0, tempUploadNode.GetAttribute("category").LastIndexOf("(") - 1), tempUploadNode.GetAttribute("status"), CurrentRequestID.Text, FileSummary.Text, comboBox1.Text, InternalUseOnlyChkBox.Checked);
            nextlistitem:
                FileNAME = "";
            }
            //foreach (TreeNode xNode in ProjectWorkbook.Nodes)
            //{
            //  RemoveNodesRecursive(xNode);
            //}

            //UploadList.DocumentElement.InnerXml = UploadList.DocumentElement.InnerXml + UploadListTemporary.DocumentElement.InnerXml;
            //UploadListTemporary.DocumentElement.InnerXml = "";
        }

        private void AddToUploadList()
        {
            String FileNAME = "", FilePATH = "", ACCOUNT = "", GroupCATEGORY = "", CATEGORY = "", DocumentSTATUS = "", FileSUMMARY1 = "", STATE = "";
            String RequestID = "";
            Boolean InternalUSEONLY;

            foreach (XmlElement tempUploadNode in UploadListTemporary.DocumentElement.GetElementsByTagName("item"))
            {
                foreach (DataGridViewRow row in UploadListing.Rows)
                {
                    if (row.Cells[0].Value != null)
                    {
                        FileNAME = row.Cells[0].Value.ToString();
                        FilePATH = row.Cells[1].Value.ToString();
                        ACCOUNT = row.Cells[2].Value.ToString();
                        GroupCATEGORY = row.Cells[3].Value.ToString();
                        CATEGORY = row.Cells[4].Value.ToString();
                        DocumentSTATUS = row.Cells[5].Value.ToString();
                        RequestID = row.Cells[6].Value.ToString();
                        FileSUMMARY1 = row.Cells[7].Value.ToString();
                        STATE = row.Cells[8].Value.ToString();
                        InternalUSEONLY = Convert.ToBoolean(row.Cells[9].Value);

                        if (FileNAME == tempUploadNode.GetAttribute("name"))
                        {
                            if (FilePATH == tempUploadNode.GetAttribute("path"))
                            {
                                if (ACCOUNT == tempUploadNode.GetAttribute("account"))
                                {
                                    if (GroupCATEGORY == tempUploadNode.GetAttribute("group"))
                                    {
                                        //if (CATEGORY == tempUploadNode.GetAttribute("category"))
                                        //{
                                        if (CATEGORY == tempUploadNode.GetAttribute("category").Substring(0, tempUploadNode.GetAttribute("category").LastIndexOf("(") - 1))
                                        {
                                            if (DocumentSTATUS == tempUploadNode.GetAttribute("status"))
                                            {
                                                if (RequestID == CurrentRequestID.Text)
                                                {
                                                    if (FileSUMMARY1 == FileSummary.Text)
                                                    {
                                                        if (STATE == comboBox1.Text)
                                                        {
                                                            if (InternalUSEONLY == InternalUseOnlyChkBox.Checked)
                                                            {
                                                                goto nextlistitem;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        //}
                                    }
                                }
                            }
                        }
                    }
                }
                UploadListing.Rows.Add(tempUploadNode.GetAttribute("name"), tempUploadNode.GetAttribute("path"), tempUploadNode.GetAttribute("account"), tempUploadNode.GetAttribute("group"), tempUploadNode.GetAttribute("category").Substring(0, tempUploadNode.GetAttribute("category").LastIndexOf("(") - 1), tempUploadNode.GetAttribute("status"), CurrentRequestID.Text, FileSummary.Text, comboBox1.Text, InternalUseOnlyChkBox.Checked);
            nextlistitem:
                FileNAME = "";
            }
            foreach (TreeNode xNode in ProjectWorkbook.Nodes)
            {
                RemoveNodesRecursive(xNode);
            }

            //UploadList.DocumentElement.InnerXml = UploadList.DocumentElement.InnerXml + UploadListTemporary.DocumentElement.InnerXml;
            UploadListTemporary.DocumentElement.InnerXml = "";
        }
        private XmlElement GetNodeDetails(TreeNode WorkbookNode)
        {

            foreach (XmlElement xmlObj in UploadListTemporary.DocumentElement.GetElementsByTagName("item"))
            {
                if (xmlObj.GetAttribute("name") == WorkbookNode.Text && xmlObj.GetAttribute("category") == WorkbookNode.Parent.Text && xmlObj.GetAttribute("group") == WorkbookNode.Parent.Parent.Text && xmlObj.GetAttribute("account") == WorkbookNode.Parent.Parent.Parent.Text)
                {
                    return xmlObj;
                }
            }
            return null;
        }
        private void RemoveNodesRecursive(TreeNode treeNode)
        {
            // Print the node.
            //System.Diagnostics.Debug.WriteLine(treeNode.Text);
            // Print each node recursively.
            TreeNode tn;
            for (int t = treeNode.Nodes.Count - 1; t > -1; t--)
            {
                tn = treeNode.Nodes[t];
                if (tn.Level == 3)
                {
                    //treeNode.Nodes.RemoveAt(tn.Index);
                    //treeNode.Text = treeNode.Text.Substring(0, treeNode.Text.LastIndexOf(" ("));
                    //treeNode.Text = treeNode.Text + " (" + treeNode.Nodes.Count.ToString() + ")";
                    tn.ForeColor = Color.FromArgb(40, 40, 40);
                }
                else
                {
                    RemoveNodesRecursive(tn);
                }
            }
        }
        private void SetStatus(string LabelText, Boolean ShowProgressBar = false, ProgressBarStyle ProgressBarState = ProgressBarStyle.Marquee)
        {
            StatusLabel.Text = LabelText;
            PB.Visible = ShowProgressBar;
            PB.Style = ProgressBarState;

        }
        private void CancelButton_Click(object sender, EventArgs e)
        {
            Upload.Enabled = true;
            CancelBtn.Visible = false;
            if (work_AllFolders.IsAlive)
            {
                work_AllFolders.Abort();
            }
        }
        private void Upload_Click(object sender, EventArgs e)
        {
            if (UploadListing.Rows.Count < 2)
            {
                MessageBox.Show("There are no items in the Upload List");
                return;
            }
            string RequestIDCheck = "";
            foreach (DataGridViewRow row in UploadListing.Rows)
            {
                if (!row.IsNewRow)
                {
                    if (row.Cells[6].Value != null)
                    {
                        if (row.Cells[6].Value.ToString() != "")
                        {
                            if (!isNumeric(row.Cells[6].Value.ToString()))
                            {
                                RequestIDCheck = RequestIDCheck + "Row " + (row.Index + 1).ToString() + " :" + " - Request ID field is not a numeric value\n";
                            }
                        }
                        else
                        {
                            RequestIDCheck = RequestIDCheck + "Row " + (row.Index + 1).ToString() + " :" + " - Request ID field is blank\n";
                        }
                    }
                    else
                    {
                        RequestIDCheck = RequestIDCheck + "Row " + (row.Index + 1).ToString() + " :" + " - Request ID field is blank\n";
                    }
                }
            }

            if (RequestIDCheck != "")
            {
                MessageBox.Show(RequestIDCheck);
                return;
            }

            CancelBtn.Visible = true;
            Upload.Enabled = false;

            GetUploadList();
            PB.Minimum = 0;
            PB.Maximum = UploadListing.Rows.Count - 1;
            PB.Value = 0;
            PB.Step = 1;
            filesCounter = 0;
            PB.Step = UploadListing.Rows.Count - 1;
            PB.Value = 0;
            SetStatus("Initializing", true, ProgressBarStyle.Marquee);
            historyLog = "Date,Message\n";

            work_AllFolders = new Thread(RunAutomation);
            work_AllFolders.SetApartmentState(ApartmentState.STA);
            work_AllFolders.IsBackground = true;
            work_AllFolders.Start();

            while (work_AllFolders.IsAlive == true)
            {
                Application.DoEvents();
                PB.Value = filesCounter;
                //if (performStep)
                //{
                //  PB.PerformStep();
                //performStep = false;
                //}
                if (threadChange == true)
                {
                    historyLog = historyLog + DateTime.Now.ToString() + "," + threadProgress + "\n";
                    if (!begunRequestProcessing)
                    {
                        SetStatus(threadProgress, true, ProgressBarStyle.Marquee);
                    }
                    else
                    {
                        SetStatus(threadProgress, true, ProgressBarStyle.Blocks);
                    }
                    threadChange = false;
                }
            }
            SetStatus("Completed", true, ProgressBarStyle.Blocks);
            //Clear
            ClearList();
            CancelBtn.Visible = false;
            //button1.Visible = false;
            Upload.Enabled = true;
            if (MessageBox.Show("Automation completed: " + filesCounter.ToString() + " file(s) uploaded" + ".\nDo you wish to open history?", "Alert", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
            {
                HistoryViewer pop = new HistoryViewer();
                pop.Show();               

            }
            SetStatus("");

        }
        private void RunAutomation()
        {
        start_automation:
            //DirectoryInfo rootFolder = new DirectoryInfo(Properties.Settings.Default.UserLocalFolder);
            WebBrowser page = new WebBrowser();
            Form browser = new Form();
            page.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(WebBrowser_DocumentCompleted);
            if (nooftimes == 1)
            {
            }
            else
            {
                browser.Controls.Add(page);
                page.Dock = DockStyle.Fill;
                //browser.Show();
                browser.Icon = Properties.Resources.dxc_iZO_icon; //from resource folder
                browser.Show();

                threadProgress = "Attempt to access Aldea";
                threadChange = true;
            }
            nooftimes = 0;
            PrevrequestID = "";

            page.Navigate(Properties.Settings.Default.UserAldeaPrefix);

            DocumentLoaded = false;
            while (!DocumentLoaded)
            {
                Application.DoEvents();
            }

            validateHPLogin(page);

            threadProgress = page.Document.Title;
            threadChange = true;

            //            if ((!page.Document.Title.Contains("Aldea")) && (!page.Document.Title.Contains("")) && (!page.Document.Title.Contains("CSC Global Pass")))
            if ((!page.Document.Title.Contains("Aldea")) && (!page.Document.Title.Contains("")))
            {
                //if (!page.Document.Title.Contains("Aldea")) 
                MessageBox.Show("An error occured while validating your account.\nYou may try to re-enter your account details and remove all blank spaces.");
                Upload.Enabled = true;
                CancelBtn.Visible = false;
                if (work_AllFolders.IsAlive)
                {
                    work_AllFolders.Abort();
                }
                return;
            }

            //MessageBox.Show(page.Document.Title);
            XmlDocument localFilesStructure = new XmlDocument();
            localFilesStructure.LoadXml(Properties.Settings.Default.LocalFolderStructure);

            XmlDocument localFilesStructureFileSummary = new XmlDocument();
            localFilesStructureFileSummary.LoadXml(Properties.Settings.Default.LocalFolderStructure);

            Boolean isReady = false;
            string requestID = "";
            string FileSummaryText = "";
            string StateText = "";
            string requestWorkbookID = "";
            string InternalUseOnlyText = "";
            begunRequestProcessing = true;
            // loop through all request folders

            int milliseconds = 10000;

            //            foreach (XmlElement filesummaryFolder in localFilesStructure.GetElementsByTagName("filesummaryFolder"))
            //          {
            //            Thread.Sleep(milliseconds);
            //          FileSummaryText = filesummaryFolder.GetAttribute("summary");
            //    }

            foreach (XmlElement requestFolder in localFilesStructure.GetElementsByTagName("requestFolder"))
            {
                //int milliseconds = 10000;
                Thread.Sleep(milliseconds);
            navigatetoaldea:
                requestID = requestFolder.GetAttribute("name");
                FileSummaryText = requestFolder.GetAttribute("summary");
                InternalUseOnlyText = requestFolder.GetAttribute("InternalUseOnly");
                StateText = requestFolder.GetAttribute("state");
                performStep = false;
                if (PrevrequestID == requestID)
                {
                    return;
                }
                page.Navigate(Properties.Settings.Default.UserAldeaPrefix + "srm/request_edit.aspx?RequestID=" + requestID);
                threadProgress = "Attempt to access url: " + Properties.Settings.Default.UserAldeaPrefix + "srm/request_edit.aspx?RequestID=" + requestID;
                threadChange = true;

                while (page.ReadyState != WebBrowserReadyState.Complete)
                {
                    Application.DoEvents();
                }

                threadProgress = page.Document.Title;
                if (page.Document.Title.Contains(""))
                {
                    Thread.Sleep(milliseconds);
                    if (page.Document.Title.Contains(requestID))
                    {
                        goto next1;
                    }
                    goto navigatetoaldea;
                }

            next1:
                threadProgress = page.Document.Title;
                if (page.Document.Title.Contains("Aldea - Home"))
                {
                    goto navigatetoaldea;
                }

                threadProgress = page.Document.Title;
                if (page.Document.Title.Contains("SAML 2.0 Auto-POST form"))
                {
                    goto navigatetoaldea;
                }

                while (page.ReadyState != WebBrowserReadyState.Complete)
                {
                    Application.DoEvents();
                }

                //                if (page.Document.Title.Contains("Global Profile Manager"))
                //              {
                //                page.Navigate(Properties.Settings.Default.UserAldeaPrefix + "srm/request_edit.aspx?RequestID=" + requestID);
                //              goto navigatetoaldea
                //        }

                //      if (!page.Document.Title.Contains("Aldea - Request #"))
                //    {
                //      goto navigatetoaldea;
                //}

                if (page.Document.GetElementById("lblMessage") == null)
                {
                    if (page.Document.GetElementById("frmInvalidRequest") != null)
                    {

                        HistoryAdd("Failure - Invalid or not accessible request", requestID, requestWorkbookID, "n/a", "n/a", "All file(s)", "All file(s)", FileSummaryText, StateText, InternalUseOnlyText);
                        continue;
                    }
                    else
                    {
                        HistoryAdd("Failure - The request could not be opened", requestID, requestWorkbookID, "n/a", "n/a", "All file(s)", "All file(s)", FileSummaryText, StateText, InternalUseOnlyText);
                        continue;
                    }
                }


                threadProgress = "Opening additional fields for request id " + requestID;
                threadChange = true;
                if (page.Document.GetElementById("leftSideLink2") != null)
                {
                    page.Document.GetElementById("leftSideLink2").InvokeMember("click");
                }
                else
                {
                    if (MessageBox.Show("An error occured while reading the additional fields.\n Do you wish to retry?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                    {
                        goto start_automation;
                    }
                    else
                    {
                        continue;
                    }
                }

                isReady = false;
                while (!isReady)
                {
                    Application.DoEvents();
                    if (page.Document.GetElementById("tab2").InnerText != null)
                    {
                        if (page.Document.GetElementById("tab2").InnerText != "")
                        {
                            isReady = true;
                        }
                    }

                }

                if (page.Document.All.GetElementsByName("Project")[0] != null)
                {
                    //MessageBox.Show(page.Document.All.GetElementsByName("Project")[0].GetAttribute("value"));
                    requestWorkbookID = page.Document.All.GetElementsByName("Project")[0].GetAttribute("value");
                    //page.Navigate("https://am.svcs.entsvcs.net/aldea/srm/workbook.aspx?ProjectID=" + requestWorkbookID);
                    //page.Navigate("https://am.svcs.entsvcs.net/aldea/srm/workbook.aspx?ProjectID=" + requestWorkbookID);
                    page.Navigate(Properties.Settings.Default.UserAldeaPrefix + "srm/workbook.aspx?ProjectID=" + requestWorkbookID);

                    threadProgress = "Attempt to access project workbook " + requestWorkbookID;
                    threadChange = true;
                    while (page.ReadyState != WebBrowserReadyState.Complete)
                    {
                        Application.DoEvents();
                    }


                    XmlDocument workbook = getWorkbookTree(page.Document.GetElementById("lblTree"));
                    string categoryLink = "";
                    string fileExtension = "";
                    string categoryId = "";
                    ArrayList extensions = new ArrayList();
                    extensions.Add("doc");
                    extensions.Add("docx");
                    extensions.Add("pptx");
                    extensions.Add("ppt");
                    extensions.Add("pdf");
                    extensions.Add("mail");
                    extensions.Add("image");
                    extensions.Add("zip");
                    extensions.Add("xls");
                    extensions.Add("xlsx");
                    extensions.Add("txt");

                    foreach (XmlElement groupFolder in requestFolder.GetElementsByTagName("groupFolder"))
                    {
                        foreach (XmlElement singleFolder in groupFolder.GetElementsByTagName("singleFolder"))
                        {
                            //requestID = singleFolder.GetAttribute("name");
                            FileSummaryText = singleFolder.GetAttribute("summary");
                            StateText = singleFolder.GetAttribute("state");
                            InternalUseOnlyText = singleFolder.GetAttribute("InternalUseOnly");

                            //if (categoryLink == "")
                            //{
                            categoryLink = getCategoryLink(groupFolder.GetAttribute("name").Replace("%26", "&"), singleFolder.GetAttribute("name").Replace("&amp;", "&"), workbook);
                            //}
                            //else
                            //{
                            //  goto nextReqFolder;
                            //}
                            if (categoryLink != null)
                            {
                                page.Navigate(categoryLink);
                                while (page.ReadyState != WebBrowserReadyState.Complete)
                                {
                                    Application.DoEvents();
                                }

                                //get local files
                                foreach (XmlElement file in singleFolder.GetElementsByTagName("file"))
                                {
                                    //if (performStep != true)
                                    FileSummaryText = file.GetAttribute("summary");
                                    StateText = file.GetAttribute("state");
                                    InternalUseOnlyText = file.GetAttribute("InternalUseOnly");
                                    //{

                                    file.SetAttribute("uploaded", "false");
                                    //get the files stored in Aldea
                                    foreach (HtmlElement a in page.Document.GetElementById("lblDocs").GetElementsByTagName("a"))
                                    {
                                        if (a.GetAttribute("class") == "DocumentTitleLink" || a.GetAttribute("className") == "DocumentTitleLink")
                                        {
                                            fileExtension = a.Parent.Parent.GetElementsByTagName("img")[0].GetAttribute("src");
                                            foreach (string ext in extensions)
                                            {
                                                if (fileExtension.Contains(ext + ".gif") == true) fileExtension = ext;
                                            }
                                            if (fileExtension == "image") fileExtension = "img";
                                            if (file.GetAttribute("name").Replace("%26", "").Trim() == a.InnerText.Replace("%26", "").Trim() + "." + fileExtension)
                                            {
                                                file.SetAttribute("uploaded", "true");
                                            }
                                            //Debug.Write(file.GetAttribute("name").Replace("%26", "").Trim() + "\n");
                                            //Debug.Write(a.InnerText.Replace("%26", "").Trim() + "." + fileExtension + "\n");
                                        }

                                    }
                                    //MessageBox.Show(file.GetAttribute("name") + " is " + file.GetAttribute("uploaded"));

                                    if (file.GetAttribute("uploaded") == "false")
                                    {
                                        categoryId = getCategoryID(groupFolder.GetAttribute("name").Replace("&amp;", "&"), singleFolder.GetAttribute("name").Replace("&amp;", "&"), workbook);
                                        threadProgress = "Opening upload file form for category id " + categoryId;
                                        threadChange = true;
                                        WebBrowser uploadFilePage = new WebBrowser();
                                        Form popupWindow = new Form();
                                        uploadFilePage.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(WebBrowser_DocumentCompleted);
                                        popupWindow.Controls.Add(uploadFilePage);

                                        uploadFilePage.Dock = DockStyle.Fill;
                                        //popupWindow.Show();
                                        popupWindow.Show();

                                        //Debug.WriteLine(Properties.Settings.Default.UserAldeaPrefix + "srm/document_edit.aspx?DocID=0&Project=" + requestWorkbookID + "&Category=" + categoryId + "&Mode=0");
                                        //Debug.WriteLine("https://am.svcs.entsvcs.net/aldea/srm/document_edit.aspx?DocID=0&Project=1111586&Category=1000228&Mode=0");
                                        uploadFilePage.Navigate(Properties.Settings.Default.UserAldeaPrefix + "srm/document_edit.aspx?DocID=0&Project=" + requestWorkbookID + "&Category=" + categoryId + "&Mode=0");
                                        //popupWindow.Show();
                                        popupWindow.Show();

                                        while (uploadFilePage.ReadyState != WebBrowserReadyState.Complete)
                                        {
                                            Application.DoEvents();
                                        }

                                        // file upload form
                                        filePath = file.GetAttribute("path");
                                        //filePath = Properties.Settings.Default.UserLocalFolder + "\\" + requestFolder.GetAttribute("name") + "\\" + groupFolder.GetAttribute("name") + "\\" + singleFolder.GetAttribute("name") + "\\" + file.GetAttribute("name");
                                        //Debug.Write(filePath + "\n");
                                        // --- HTML File upload text box 
                                        threadProgress = "Attempt to attach " + filePath + " to " + requestFolder.GetAttribute("name") + " > " + groupFolder.GetAttribute("name") + " > " + singleFolder.GetAttribute("name");
                                        threadChange = true;

                                        Thread WindowsMonitor;
                                        WindowsMonitor = new Thread(UploadFile);
                                        WindowsMonitor.SetApartmentState(ApartmentState.STA);
                                        WindowsMonitor.IsBackground = true;
                                        WindowsMonitor.Start();
                                        try
                                        {
                                            //Debug.WriteLine(uploadFilePage.Url.ToString());                              
                                            //uploadFilePage.Document.GetElementById("cphPopupWindowContent_fileInput").InvokeMember("click");
                                            uploadFilePage.Document.GetElementById("ctl00$cphPopupWindowContent$fileInput").InvokeMember("click");
                                        }
                                        catch (Exception exc)
                                        {
                                            if (MessageBox.Show("An error occured while accessing the upload form.\nDo you wish to continue?", "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                                            {
                                                WindowsMonitor = null;
                                                goto start_automation;
                                            }
                                        }

                                        while (WindowsMonitor.IsAlive == true)
                                        {
                                            Application.DoEvents();
                                        }
                                        //uploadFilePage.Document.GetElementById("cphPopupWindowContent_txtTitle").SetAttribute("value", file.GetAttribute("name"));
                                        uploadFilePage.Document.GetElementById("ctl00$cphPopupWindowContent$txtTitle").SetAttribute("value", file.GetAttribute("name"));

                                        //***### adding request number field. CHECK FOR WHICH ACCOUNT IS REQUIERD ###***
                                        //                               
                                        //uploadFilePage.Document.GetElementById("cphPopupWindowContent_txtRequest").SetAttribute("value", requestID);
                                        uploadFilePage.Document.GetElementById("ctl00$cphPopupWindowContent$txtRequest").SetAttribute("value", requestID);
                                        uploadFilePage.Document.GetElementById("cphPopupWindowContent_txtSummary").SetAttribute("value", FileSummaryText);

                                        threadProgress = groupFolder.GetAttribute
                                        ("name").Replace("%26", "&");
                                        threadChange = true;

                                        threadProgress = singleFolder.GetAttribute("name").Replace("%26", "&");
                                        threadChange = true;

                                        if (StateText == "Public Draft")
                                        #region unused code
                                        //if (getCategoryType(groupFolder.GetAttribute("name").Replace("%26", "&"), singleFolder.GetAttribute("name").Replace("%26", "&"), workbook) == "blue")
                                        {
                                            //is in blue category
                                            //Debug.Write("Blue category " + singleFolder.GetAttribute("name") + "\n");
                                            //SelectOption(uploadFilePage.Document.GetElementById("cphPopupWindowContent_ddlStatus"), "Public Draft");
                                            // ------- Public Draft ------------
                                            //SelectOption(uploadFilePage.Document.GetElementById("ctl00$cphPopupWindowContent$ddlStatus"), "Public Draft");
                                            //uploadFilePage.Document.GetElementById("cphPopupWindowContent_chkInternalUse").InvokeMember("click");

                                            // ------- Internal Use ------------
                                            //uploadFilePage.Document.GetElementById("cphPopupWindowContent_chkInternalUse").InvokeMember("click");

                                            //SelectOption(uploadFilePage.Document.GetElementById("ctl00$cphPopupWindowContent$ddlStatus"), "Final");

                                            //Public Draft
                                            #endregion
                                            threadProgress = getCategoryType(groupFolder.GetAttribute("name").Replace("%26", "&"), singleFolder.GetAttribute("name").Replace("%26", "&"), workbook);
                                            threadChange = true;

                                            SelectOption(uploadFilePage.Document.GetElementById("ctl00$cphPopupWindowContent$ddlStatus"), "Public Draft");
                                        }
                                        else if (StateText == "Final")
                                        {

                                            threadProgress = getCategoryType(groupFolder.GetAttribute("name").Replace("%26", "&"), singleFolder.GetAttribute("name").Replace("%26", "&"), workbook);
                                            threadChange = true;

                                            //is red category
                                            //Debug.Write("Red category " + singleFolder.GetAttribute("name") + "\n");
                                            //SelectOption(uploadFilePage.Document.GetElementById("cphPopupWindowContent_ddlStatus"), "Final");
                                            SelectOption(uploadFilePage.Document.GetElementById("ctl00$cphPopupWindowContent$ddlStatus"), "Final");
                                            //uploadFilePage.Document.GetElementById("cphPopupWindowContent_chkInternalUse").InvokeMember("click");
                                        }

                                        if (InternalUseOnlyText == "True")
                                        {
                                            uploadFilePage.Document.GetElementById("cphPopupWindowContent_chkInternalUse").InvokeMember("click");
                                        }


                                        // end file upload form

                                        uploadFilePage.Document.GetElementById("lblPageTitle").InnerText = "Loading";
                                        if (Properties.Settings.Default.UserTestMode == true)
                                        {
                                            //uploadFilePage.Document.GetElementById("bnCancel").InvokeMember("click");
                                            uploadFilePage.Document.GetElementById("bnCancelBottom").InvokeMember("click");
                                            //Debug.Write("Simulating");
                                        }
                                        else
                                        {
                                            //uploadFilePage.Document.GetElementById("bnOK").InvokeMember("click");
                                            uploadFilePage.Document.GetElementById("bnOKbottom").InvokeMember("click");
                                            //Debug.Write("Saving");
                                        }

                                        DocumentLoaded = false;
                                        while (!DocumentLoaded)
                                        {
                                            Application.DoEvents();
                                            if (uploadFilePage.Document.GetElementById("lblPageTitle") == null)
                                            {

                                            }
                                        }
                                        if (uploadFilePage.Document != null)
                                        {
                                            if (uploadFilePage.Document.Title != null)
                                            {
                                                if (uploadFilePage.Document.Title == "Could Not Open Page")
                                                {
                                                    HistoryAdd("Failure: The file could not be uploaded", requestID, requestWorkbookID, groupFolder.GetAttribute("name"), singleFolder.GetAttribute("name"), file.GetAttribute("name"), filePath, FileSummaryText);
                                                    goto loop_close;
                                                }
                                            }
                                        }
                                        HistoryAdd("Success", requestID, requestWorkbookID, groupFolder.GetAttribute("name"), singleFolder.GetAttribute("name"), file.GetAttribute("name"), filePath, FileSummaryText, StateText, InternalUseOnlyText);
                                        PrevrequestID = requestID;

                                        //while (uploadFilePage.Document.GetElementById("lblPageTitle") != null)
                                        //{
                                        //    Application.DoEvents();
                                        //    if (uploadFilePage.Document != null)
                                        //    {
                                        //        if (uploadFilePage.Document.GetElementById("lblPageTitle") != null)
                                        //        {
                                        //            if (uploadFilePage.Document.GetElementById("lblPageTitle").InnerText != null)
                                        //            {
                                        //                if (uploadFilePage.Document.GetElementById("lblPageTitle").InnerText != "Loading")
                                        //                {
                                        //                    break;
                                        //                }
                                        //            }
                                        //        }
                                        //    }
                                        //}
                                        //FOR CLICKING "RESERVE" BUTTON
                                        uploadFilePage.Document.GetElementById("bnReserve").InvokeMember("Click");
                                    loop_close:
                                        threadProgress = "Closing upload form";
                                        threadChange = true;
                                        popupWindow.Close();
                                    }
                                    else
                                    {
                                        threadProgress = file.GetAttribute("name") + " was already uploaded";
                                        threadChange = true;
                                        HistoryAdd("Already uploaded", requestID, requestWorkbookID, groupFolder.GetAttribute("name"), singleFolder.GetAttribute("name"), file.GetAttribute("name"), filePath, FileSummaryText, StateText, InternalUseOnlyText);

                                    }

                                    filesCounter = filesCounter + 1;
                                    threadChange = true;
                                    performStep = true;
                                }
                                //}
                            }
                            else
                            {
                                HistoryAdd("Failure - Category not found", requestID, requestWorkbookID, groupFolder.GetAttribute("name"), singleFolder.GetAttribute("name").Replace("&", "&amp;"), "All file(s)", "All file(s)", FileSummaryText, StateText, InternalUseOnlyText);
                            }
                            //categoryLink = null;
                        }
                        //nextReqFolder:

                        //if (categoryLink == null)
                        //                        {
                        //goto nextreqfodler1;
                        //                      }
                    }
                }
                else
                {
                    //MessageBox.Show(requestFolder.GetAttribute("name") + " does not have a project workbook");
                }
            }

            //exit_automation:
            //            //exit sub
        }

        private void validateHPLogin(WebBrowser webbrowserObject)
        {
            Boolean PassedLogin1 = false;

        start_loop:

            //if (webbrowserObject.Document.Title == "HP Log on")
            if (webbrowserObject.Document.Title == "DXC Global Pass - Login")
            {
                Application.DoEvents();
                //if (Status != null) Status.Text = "Validating email address and password";
                DocumentLoaded = false;
                try
                {
                    webbrowserObject.Document.GetElementById("USER").SetAttribute("value", Properties.Settings.Default.UserEmail);
                }
                catch
                {
                    Application.DoEvents();
                    goto start_loop;
                }
                webbrowserObject.Document.All.GetElementsByName("PASSWORD")[0].SetAttribute("value", Properties.Settings.Default.UserPassword);
                //webbrowserObject.Document.GetElementById("loginbtn").InvokeMember("submit");
                //webbrowserObject.Document.GetElementById("loginbtn");
                webbrowserObject.Document.GetElementById("loginbtn").InvokeMember("Click");
                //webbrowserObject.Document.InvokeScript("submitForm");
                //webbrowserObject.Document.GetElementById("loginbtn").InvokeMember("Click");
                while (!DocumentLoaded)
                {
                    Application.DoEvents();
                }
                while (!DocumentLoaded)
                {
                    Application.DoEvents();
                }
                PassedLogin1 = true;
            }

            if (webbrowserObject.Document.Title.Contains("DXC : Logon"))
            {
                //if (Status != null) Status.Text = "Validating email address and password";
                DocumentLoaded = false;
                //webbrowserObject.Size=new Size(1500, 1500);
                webbrowserObject.Document.GetElementById("USERNAME").SetAttribute("value", Properties.Settings.Default.UserEmail);
                //webbrowserObject.Document.GetElementById("PASSWORD").SetAttribute("value", Properties.Settings.Default.UserPassword);
                webbrowserObject.Document.All.GetElementsByName("PASSWORD")[0].SetAttribute("value", Properties.Settings.Default.UserPassword);
                //webbrowserObject.Document.GetElementById("LOGONBUT").InvokeMember("submit");
                //webbrowserObject.Document.GetElementById("LOGONBUT");
                //webbrowserObject.Document.InvokeScript("showprocessing");
                webbrowserObject.Document.GetElementById("LOGONBUT").InvokeMember("Click");
                while (!DocumentLoaded)
                {
                    Application.DoEvents();
                }
                while (!DocumentLoaded)
                {
                    Application.DoEvents();
                }
                PassedLogin1 = true;
            }
            if (webbrowserObject.Document.Title == "HP Employee Portal")
            {
                //USER
                webbrowserObject.Document.All.GetElementsByName("USER")[0].SetAttribute("value", Properties.Settings.Default.UserEmail);
                webbrowserObject.Document.All.GetElementsByName("PASSWORD")[0].SetAttribute("value", Properties.Settings.Default.UserPassword);
                webbrowserObject.Document.InvokeScript("trimAndSubmit");
                while (webbrowserObject.Document.Title == "HP Employee Portal")
                {
                    Application.DoEvents();
                }
                PassedLogin1 = true;
            }

            if (webbrowserObject.Document.Title == "HP SiteMinder Login")
            {
                //EDIT
                webbrowserObject.Document.All.GetElementsByName("USER")[0].InnerText = Properties.Settings.Default.UserEmail;
                webbrowserObject.Document.All.GetElementsByName("PASSWORD")[0].InnerText = Properties.Settings.Default.UserPassword;
                webbrowserObject.Document.GetElementsByTagName("input")[11].InvokeMember("Click");
                while (webbrowserObject.Document.Title == "HP SiteMinder Login")
                {
                    Application.DoEvents();
                }
                PassedLogin1 = true;
            }

            if (webbrowserObject.Document.Title.Contains("USPS SRA: Logon"))
            {
                //EDIT
                DocumentLoaded = false;
                webbrowserObject.Document.GetElementById("USERNAME").SetAttribute("value", Properties.Settings.Default.UserEmail);
                webbrowserObject.Document.All.GetElementsByName("PASSWORD")[0].SetAttribute("value", Properties.Settings.Default.UserPassword);
                webbrowserObject.Document.GetElementById("LOGONBUT").InvokeMember("Click");
                while (!DocumentLoaded)
                {
                    Application.DoEvents();
                }
                while (!DocumentLoaded)
                {
                    Application.DoEvents();
                }
                PassedLogin1 = true;
            }

            if (!webbrowserObject.Document.Title.Contains("Aldea"))
            {
                if (PassedLogin1)
                {
                    if (webbrowserObject.Document.Title.Contains("CSC"))
                    {
                        nooftimes = 1;
                        RunAutomation();
                    }
                    if (webbrowserObject.Document.Title == "")
                    {
                        nooftimes = 1;
                        RunAutomation();
                    }

                    while (webbrowserObject.ReadyState != WebBrowserReadyState.Complete)
                    {
                        Application.DoEvents();
                    }
                    return;
                }
                else
                {
                    Application.DoEvents();
                    goto start_loop;
                }
            }
        }
        private void GetUploadList()
        {
            XmlDocument localFolders = new XmlDocument();
            XmlDocument localFoldersFileSummary = new XmlDocument();

            localFolders.LoadXml("<local></local>");
            localFoldersFileSummary.LoadXml("<local></local>");
            string requestFolder = "";
            string groupFolder = "";
            string categoryFolder = "";
            string fileNodeStr = "";
            string filesummaryFolder = "";

            XmlElement filesummaryNodeStr;
            XmlElement requestNode;
            XmlElement groupNode;
            XmlElement categoryNode;

            foreach (DataGridViewRow row in UploadListing.Rows)
            {
                if (!row.IsNewRow)
                {
                    // CREATE / SET THE REQUEST XML NODE
                    requestNode = FindElementByAttribute(localFolders.DocumentElement, "requestFolder", "name", row.Cells[6].Value.ToString(), row.Cells[7].Value.ToString(), row.Cells[8].Value.ToString(), row.Cells[9].Value.ToString());
                    if (requestNode == null)
                    {
                        //requestFolder = "<requestFolder account='" + row.Cells[2].Value.ToString() + "' name='" + row.Cells[6].Value.ToString() + "'></requestFolder>";
                        requestFolder = "<requestFolder account='" + row.Cells[2].Value.ToString() + "' name='" + row.Cells[6].Value.ToString() + "' summary='" + row.Cells[7].Value.ToString() + "' state='" + row.Cells[8].Value.ToString() + "' InternalUseOnly='" + row.Cells[9].Value.ToString() + "'></requestFolder>";
                        localFolders.DocumentElement.InnerXml = localFolders.DocumentElement.InnerXml + requestFolder;
                        requestNode = FindElementByAttribute(localFolders.DocumentElement, "requestFolder", "name", row.Cells[6].Value.ToString(), row.Cells[7].Value.ToString(), row.Cells[8].Value.ToString(), row.Cells[9].Value.ToString());
                    }

                    // CREATE / SET THE GROUP XML NODE
                    groupNode = FindElementByAttribute(requestNode, "groupFolder", "name", row.Cells[3].Value.ToString(), row.Cells[7].Value.ToString(), row.Cells[8].Value.ToString(), row.Cells[9].Value.ToString());
                    if (groupNode == null)
                    {
                        groupFolder = "<groupFolder name='" + row.Cells[3].Value.ToString() + "'></groupFolder>";
                        requestNode.InnerXml = requestNode.InnerXml + groupFolder;
                        groupNode = FindElementByAttribute(requestNode, "groupFolder", "name", row.Cells[3].Value.ToString(), row.Cells[7].Value.ToString(), row.Cells[8].Value.ToString(), row.Cells[9].Value.ToString());

                    }

                    // CREATE / SET THE CATEGORY XML NODE
                    categoryNode = FindElementByAttribute(groupNode, "singleFolder", "name", row.Cells[4].Value.ToString(), row.Cells[7].Value.ToString(), row.Cells[8].Value.ToString(), row.Cells[9].Value.ToString());
                    if (categoryNode == null)
                    {
                        categoryFolder = "<singleFolder name='" + row.Cells[4].Value.ToString().Replace("&", "&amp;") + "' summary='" + row.Cells[7].Value.ToString() + "' state='" + row.Cells[8].Value.ToString() + "' InternalUseOnly='" + row.Cells[9].Value.ToString() + "'></singleFolder>";
                        groupNode.InnerXml = groupNode.InnerXml + categoryFolder;
                        categoryNode = FindElementByAttribute(groupNode, "singleFolder", "name", row.Cells[4].Value.ToString(), row.Cells[7].Value.ToString(), row.Cells[8].Value.ToString(), row.Cells[9].Value.ToString());

                    }

                    // CREATE THE FILE XML NODE
                    fileNodeStr = "<file name='" + row.Cells[0].Value.ToString().Replace("&", "&amp;") + "' path='" + row.Cells[1].Value.ToString().Replace("&", "&amp;") + "' summary='" + row.Cells[7].Value.ToString() + "' state='" + row.Cells[8].Value.ToString() + "' InternalUseOnly='" + row.Cells[9].Value.ToString() + "'/>";
                    categoryNode.InnerXml = categoryNode.InnerXml + fileNodeStr;

                    // FILE SUMMARY
                    //                filesummaryNodeStr = FindElementByAttribute(localFolders.DocumentElement, "requestFolder", "name", row.Cells[7].Value.ToString());
                    //              if (filesummaryNodeStr == null)
                    //            { 
                    //              filesummaryFolder = "<file summary='" + row.Cells[7].Value.ToString() + "'/>";
                    //            localFoldersFileSummary.DocumentElement.InnerXml = localFoldersFileSummary.DocumentElement.InnerXml + filesummaryFolder;
                    //          filesummaryNodeStr = FindElementByAttribute(localFoldersFileSummary.DocumentElement, "requestFolder", "name", row.Cells[7].Value.ToString());
                    //    }
                }
            }
            //Debug.WriteLine(localFolders.DocumentElement.InnerXml);
            Properties.Settings.Default.LocalFolderStructure = localFolders.DocumentElement.OuterXml;
            Properties.Settings.Default.Save();

            //            Properties.Settings.Default.LocalFolderStructure = localFoldersFileSummary.DocumentElement.OuterXml;
            //          Properties.Settings.Default.Save();

        }
        //private XmlElement FindElementByAttribute(XmlElement XmlObject, string TagName, string AttributeName, string AttributeValue)
        private XmlElement FindElementByAttribute(XmlElement XmlObject, string TagName, string AttributeName, string AttributeValue, string filesummaryvalue, string state, string InternalUseOnly)
        {
            foreach (XmlElement node in XmlObject.GetElementsByTagName(TagName))
            {
                if (node.GetAttribute(AttributeName) == AttributeValue) return node;
            }
            return null;
        }
        void UploadFile()
        {
            IntPtr h1 = WinApiUser32.FindWindow("#32770", "Choose File to Upload");
            while (h1.ToInt32() < 1)
            {
                Application.DoEvents();
                h1 = WinApiUser32.FindWindow("#32770", "Choose File to Upload");
            }
            IntPtr htextbox;
            IntPtr htextbox1;
            IntPtr htextbox2;
            int WM_SETTEXT = 0x000C;
            int WM_LBUTTONDOWN = 0x0201;
            int WM_LBUTTONUP = 0x0202;

            htextbox = WinApiUser32.FindWindowEx(h1, 0, "ComboBoxEx32", null);
            htextbox1 = WinApiUser32.FindWindowEx(h1, 0, "DUIViewWndClassName", null);
            htextbox2 = WinApiUser32.FindWindowEx(htextbox, 0, "ComboBox", null);
            if (htextbox2.ToInt32() > 0)
            {
                //get file path control by window
                IntPtr htextbox5 = WinApiUser32.FindWindowEx(htextbox2, 0, "Edit", null);
                //set file path
                //MessageBox.Show(filePath);
                WinApiUser32.SendMessage(htextbox5, WM_SETTEXT, IntPtr.Zero, "file:///" + filePath);

                //open button
                IntPtr hbutton;
                //get open button
                hbutton = WinApiUser32.FindWindowEx(h1, 0, "BUTTON", "&Open");
                if (hbutton.ToInt32() > 0)
                {
                    WinApiUser32.SendMessage(hbutton, WM_LBUTTONDOWN, IntPtr.Zero, null);
                    WinApiUser32.SendMessage(hbutton, WM_LBUTTONUP, IntPtr.Zero, null);
                }
            }

        }
        void SelectOption(HtmlElement htmlSelectTag, string textValue)
        {
            foreach (HtmlElement opts in htmlSelectTag.GetElementsByTagName("option"))
            {
                if (opts.InnerText == textValue)
                {
                    opts.SetAttribute("selected", "selected");
                    htmlSelectTag.SetAttribute("value", opts.GetAttribute("value"));
                    break;
                }
            }
        }
        private void HistoryAdd(string Status, string RequestID, string WorkbookID, string CategorySection = "", string Section = "", string FileName = "", string LocalFilePath = "", string FileSummaryText = "", string StateText = "", string InternalUseOnly = "")
        {
            XmlDocument localHistory = new XmlDocument();
            if (Properties.Settings.Default.UserHistory != "")
            {
                localHistory.LoadXml(Properties.Settings.Default.UserHistory);
            }
            else
            {
                localHistory.LoadXml("<history></history>");

            }
            localHistory.DocumentElement.InnerXml += "<item Status='" + Status + "' Date='" + DateTime.Now + "' RequestID='" + RequestID + "' WorkbookID='" + WorkbookID + "'  CategorySection='" + CategorySection + "'  Section='" + Section.Replace("&", "&amp;") + "' FileName='" + FileName.Replace("&", "&amp;") + "' LocalFilePath='" + LocalFilePath.Replace("&", "&amp;") + "' FileSummary='" + FileSummaryText + "' State='" + StateText + "' InternalUseOnly='" + InternalUseOnly + "'/>";
            Properties.Settings.Default.UserHistory = localHistory.DocumentElement.OuterXml;
            Properties.Settings.Default.Save();

        }
        private XmlDocument getWorkbookTree(HtmlElement HTMLTreeElement)
        {
            XmlDocument builder = new XmlDocument();
            builder.LoadXml("<workbook id=''></workbook>");
            string tempNode = "";
            Boolean isNodeOpened = false;
            string categoryId = "";
            string categoryType = "blue";
            foreach (HtmlElement tr in HTMLTreeElement.GetElementsByTagName("tr"))
            {

                if (tr.GetElementsByTagName("b").Count > 0)
                {
                    if (isNodeOpened == true) tempNode += "</group>";
                    tempNode += "<group name='" + tr.InnerText.Replace("&", "%26") + "'>";
                    isNodeOpened = true;
                }
                else
                {
                    categoryType = "blue";
                    if (tr.GetElementsByTagName("a").Count > 0)
                    {
                        if (tr.GetElementsByTagName("a")[0].GetElementsByTagName("font").Count > 0)
                        {
                            categoryType = "red";
                        }
                        categoryId = tr.GetElementsByTagName("a")[0].GetAttribute("href");
                        categoryId = categoryId.Substring(categoryId.IndexOf("CategoryID=") + 11, categoryId.Length - categoryId.IndexOf("CategoryID=") - 11);
                        categoryId = categoryId.Substring(0, categoryId.IndexOf("&"));
                        tempNode += "<category name='" + tr.InnerText.Replace("&", "%26") + "' link='" + tr.GetElementsByTagName("a")[0].GetAttribute("href").Replace("&", "%26") + "' categoryId='" + categoryId + "' type='" + categoryType + "'/>";
                    }
                }
            }
            tempNode += "</group>";
            builder.DocumentElement.InnerXml = tempNode;
            return builder;
        }
        private string getCategoryType(string group, string category, XmlDocument workbook)
        {
            foreach (XmlElement groupNode in workbook.GetElementsByTagName("group"))
            {
                if (matchStrings(groupNode.GetAttribute("name"), group) == true)
                {
                    foreach (XmlElement categoryNode in groupNode.GetElementsByTagName("category"))
                    {
                        if (matchStrings(categoryNode.GetAttribute("name"), category) == true)
                        {
                            return categoryNode.GetAttribute("type");
                        }
                    }
                }
            }
            return null;
        }
        private string getCategoryID(string group, string category, XmlDocument workbook)
        {
            foreach (XmlElement groupNode in workbook.GetElementsByTagName("group"))
            {
                if (groupNode.GetAttribute("name").Replace("%26", "&").Replace(" ", "") == group.Replace(" ", ""))
                {
                    foreach (XmlElement categoryNode in groupNode.GetElementsByTagName("category"))
                    {
                        if (categoryNode.GetAttribute("name").Replace("%26", "&").Replace(" ", "") == category.Replace(" ", ""))
                        {
                            return categoryNode.GetAttribute("categoryId");
                        }
                    }
                }
            }
            return null;
        }
        private string getCategoryLink(string group, string category, XmlDocument workbook)
        {
            //Debug.Write(workbook.DocumentElement.InnerXml);
            foreach (XmlElement groupNode in workbook.GetElementsByTagName("group"))
            {
                if (groupNode.GetAttribute("name").Replace("%26", "&").Replace(" ", "") == group.Replace(" ", ""))
                {
                    foreach (XmlElement categoryNode in groupNode.GetElementsByTagName("category"))
                    {
                        if (categoryNode.GetAttribute("name").Replace("%26", "&").Replace(" ", "") == category.Replace(" ", ""))
                        {
                            Debug.WriteLine(categoryNode.GetAttribute("link").Replace("%26", "&"));
                            return categoryNode.GetAttribute("link").Replace("%26", "&");
                        }
                    }
                }

            }
            return null;
        }
        private Boolean matchStrings(string string1, string string2)
        {
            string str1 = string1;
            if (str1 != null)
            {
                str1 = str1.ToLower();
            }
            string str2 = string2;
            if (str2 != null)
            {
                str2 = str2.ToLower();
            }
            string excludedChars = "";
            excludedChars = " 1234567890_-+=;:'<>.,/|";


            foreach (char chr in excludedChars.ToCharArray())
            {
                if (str1 != null)
                {
                    str1 = str1.Replace(chr.ToString(), "");
                }
                if (str2 != null)
                {
                    str2 = str2.Replace(chr.ToString(), "");
                }
            }

            if (str1 == str2)
            {
                return true;
            }
            else
            {
                return false;
            }


        }
        private void expandAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (TreeNode node in ProjectWorkbook.Nodes)
            {
                node.ExpandAll();
            }
        }
        //private void aLUToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    if (aLUToolStripMenuItem.Checked)
        //    {
        //        XmlDocument LocalWorkbook = new XmlDocument();
        //        LocalWorkbook.LoadXml(Properties.Settings.Default.LocalWorkbooks);
        //        foreach (XmlElement elem in LocalWorkbook.DocumentElement.GetElementsByTagName("structure"))
        //        {
        //            if (elem.GetAttribute("name") == "ALU Account")
        //            {
        //                elem.SetAttribute("visible", "TRUE");
        //            }
        //        }
        //        Properties.Settings.Default.LocalWorkbooks = LocalWorkbook.DocumentElement.OuterXml;
        //        Properties.Settings.Default.Save();
        //        UpdateWorkbook();
        //    }
        //    else
        //    {
        //        foreach (TreeNode node in ProjectWorkbook.Nodes)
        //        {
        //            if (node.Level == 0 && node.Text == "ALU Account")
        //            {
        //                node.Remove();
        //                break;
        //            }
        //        }

        //        XmlDocument LocalWorkbook = new XmlDocument();
        //        LocalWorkbook.LoadXml(Properties.Settings.Default.LocalWorkbooks);
        //        foreach (XmlElement elem in LocalWorkbook.DocumentElement.GetElementsByTagName("structure"))
        //        {
        //            if (elem.GetAttribute("name") == "ALU Account")
        //            {
        //                elem.SetAttribute("visible", "FALSE");
        //            }
        //        }
        //        Properties.Settings.Default.LocalWorkbooks = LocalWorkbook.DocumentElement.OuterXml;
        //        Properties.Settings.Default.Save();
        //    }
        //}

        //private void eONToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    if (eONToolStripMenuItem.Checked)
        //    {
        //        XmlDocument LocalWorkbook = new XmlDocument();
        //        LocalWorkbook.LoadXml(Properties.Settings.Default.LocalWorkbooks);
        //        foreach (XmlElement elem in LocalWorkbook.DocumentElement.GetElementsByTagName("structure"))
        //        {
        //            if (elem.GetAttribute("name") == "EON Account")
        //            {
        //                elem.SetAttribute("visible", "TRUE");
        //            }
        //        }
        //        Properties.Settings.Default.LocalWorkbooks = LocalWorkbook.DocumentElement.OuterXml;
        //        Properties.Settings.Default.Save();

        //        UpdateWorkbook();
        //    }
        //    else
        //    {
        //        foreach (TreeNode node in ProjectWorkbook.Nodes)
        //        {
        //            if (node.Level == 0 && node.Text == "EON Account")
        //            {
        //                node.Remove();
        //                break;
        //            }
        //        }

        //        XmlDocument LocalWorkbook = new XmlDocument();
        //        LocalWorkbook.LoadXml(Properties.Settings.Default.LocalWorkbooks);
        //        foreach (XmlElement elem in LocalWorkbook.DocumentElement.GetElementsByTagName("structure"))
        //        {
        //            if (elem.GetAttribute("name") == "EON Account")
        //            {
        //                elem.SetAttribute("visible", "FALSE");
        //            }
        //        }
        //        Properties.Settings.Default.LocalWorkbooks = LocalWorkbook.DocumentElement.OuterXml;
        //        Properties.Settings.Default.Save();
        //    }
        //}
        private void GetAccount(string AccountName)
        {
            if (AccountName == "ALU")
            {
                ProjectWorkbook.Nodes.Clear();
                XmlDocument LocalWorkbook = new XmlDocument();
                LocalWorkbook.LoadXml(Properties.Settings.Default.LocalWorkbooks);
                foreach (XmlElement elem in LocalWorkbook.DocumentElement.GetElementsByTagName("structure"))
                {
                    if (elem.GetAttribute("name") == "ALU Account")
                    {
                        elem.SetAttribute("visible", "TRUE");
                    }
                }
                Properties.Settings.Default.LocalWorkbooks = LocalWorkbook.DocumentElement.OuterXml;
                Properties.Settings.Default.Save();
                UpdateWorkbook();
            }
            else if (AccountName == "EON")
            {
                ProjectWorkbook.Nodes.Clear();
                XmlDocument LocalWorkbook = new XmlDocument();
                LocalWorkbook.LoadXml(Properties.Settings.Default.LocalWorkbooks);
                foreach (XmlElement elem in LocalWorkbook.DocumentElement.GetElementsByTagName("structure"))
                {
                    if (elem.GetAttribute("name") == "EON Account")
                    {
                        elem.SetAttribute("visible", "TRUE");
                    }
                }
                Properties.Settings.Default.LocalWorkbooks = LocalWorkbook.DocumentElement.OuterXml;
                Properties.Settings.Default.Save();
                UpdateWorkbook();
            }
        }
        private void ProjectWorkbook_AfterExpand(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Level == 0)
            {
                XmlDocument LocalWorkbook = new XmlDocument();
                LocalWorkbook.LoadXml(Properties.Settings.Default.LocalWorkbooks);
                foreach (XmlElement elem in LocalWorkbook.DocumentElement.GetElementsByTagName("structure"))
                {
                    if (elem.GetAttribute("name") == e.Node.Text)
                    {
                        elem.SetAttribute("expanded", "YES");
                    }
                }
                Properties.Settings.Default.LocalWorkbooks = LocalWorkbook.DocumentElement.OuterXml;
                Properties.Settings.Default.Save();
            }
            else
            {
                XmlDocument LocalWorkbook = new XmlDocument();
                LocalWorkbook.LoadXml(Properties.Settings.Default.LocalWorkbooks);
                foreach (XmlElement elem in LocalWorkbook.DocumentElement.GetElementsByTagName("structure"))
                {
                    if (elem.GetAttribute("name") == e.Node.Parent.Text)
                    {
                        foreach (XmlElement group in elem.GetElementsByTagName("group"))
                        {
                            if (group.GetAttribute("name") == e.Node.Text)
                            {
                                group.SetAttribute("expanded", "YES");
                                break;
                            }
                        }
                    }
                }
                Properties.Settings.Default.LocalWorkbooks = LocalWorkbook.DocumentElement.OuterXml;
                Properties.Settings.Default.Save();
            }
        }
        private void ProjectWorkbook_AfterCollapse(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Level == 0)
            {
                XmlDocument LocalWorkbook = new XmlDocument();
                LocalWorkbook.LoadXml(Properties.Settings.Default.LocalWorkbooks);
                foreach (XmlElement elem in LocalWorkbook.DocumentElement.GetElementsByTagName("structure"))
                {
                    if (elem.GetAttribute("name") == e.Node.Text)
                    {
                        elem.SetAttribute("expanded", "NO");
                    }
                }
                Properties.Settings.Default.LocalWorkbooks = LocalWorkbook.DocumentElement.OuterXml;
                Properties.Settings.Default.Save();
            }
            else
            {
                XmlDocument LocalWorkbook = new XmlDocument();
                LocalWorkbook.LoadXml(Properties.Settings.Default.LocalWorkbooks);
                foreach (XmlElement elem in LocalWorkbook.DocumentElement.GetElementsByTagName("structure"))
                {
                    if (elem.GetAttribute("name") == e.Node.Parent.Text)
                    {
                        foreach (XmlElement group in elem.GetElementsByTagName("group"))
                        {
                            if (group.GetAttribute("name") == e.Node.Text)
                            {
                                group.SetAttribute("expanded", "NO");
                                break;
                            }
                        }
                    }
                }
                Properties.Settings.Default.LocalWorkbooks = LocalWorkbook.DocumentElement.OuterXml;
                Properties.Settings.Default.Save();
            }
        }
        private void removeFromTreeAndUploadListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ProjectWorkbook.SelectedNode.Parent != null && ProjectWorkbook.SelectedNode.Level == 3)
            {

                ProjectWorkbook.SelectedNode.Parent.Text = ProjectWorkbook.SelectedNode.Parent.Text.Substring(0, ProjectWorkbook.SelectedNode.Parent.Text.LastIndexOf("(") + 1) + "0)";
                ProjectWorkbook.SelectedNode.Parent.Nodes.Clear();
            }

        }
        private void fromTreeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ProjectWorkbook.SelectedNode.Level == 3)
            {
                //ProjectWorkbook.SelectedNode.Parent.Text = ProjectWorkbook.SelectedNode.Parent.Text.Substring(0, ProjectWorkbook.SelectedNode.Parent.Text.LastIndexOf("(") + 1) + (int)(ProjectWorkbook.SelectedNode.Parent.Nodes.Count - 1) + ")";
                ProjectWorkbook.SelectedNode.Parent.Nodes.Remove(ProjectWorkbook.SelectedNode);
            }
        }
        private void fromTreeAndUploadListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ProjectWorkbook.SelectedNode.Level == 3)
            {
                foreach (DataGridViewRow row in UploadListing.Rows)
                {

                    if ((string)(row.Cells[2].Value) == ProjectWorkbook.SelectedNode.Parent.Parent.Parent.Text)
                    {

                        if ((string)(row.Cells[3].Value) == ProjectWorkbook.SelectedNode.Parent.Parent.Text)
                        {
                            if ((string)(row.Cells[4].Value) == ProjectWorkbook.SelectedNode.Parent.Text.Substring(0, ProjectWorkbook.SelectedNode.Parent.Text.LastIndexOf(" (")))
                            {
                                if ((string)(row.Cells[0].Value) == ProjectWorkbook.SelectedNode.Text)
                                {
                                    UploadListing.Rows.RemoveAt(row.Index);
                                }
                            }
                        }
                    }
                }
                try
                {
                    ProjectWorkbook.SelectedNode.Parent.Text = ProjectWorkbook.SelectedNode.Parent.Text.Substring(0, ProjectWorkbook.SelectedNode.Parent.Text.LastIndexOf("(") + 1) + (int)(ProjectWorkbook.SelectedNode.Parent.Nodes.Count - 1) + ")";
                    ProjectWorkbook.SelectedNode.Parent.Nodes.Remove(ProjectWorkbook.SelectedNode);
                }
                catch
                {

                }
            }
        }
        private void fromFolderAndUploadListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ProjectWorkbook.SelectedNode.Level == 3)
            {
                foreach (TreeNode tn in ProjectWorkbook.SelectedNode.Parent.Nodes)
                {
                    foreach (DataGridViewRow row in UploadListing.Rows)
                    {

                        if ((string)(row.Cells[2].Value) == tn.Parent.Parent.Parent.Text)
                        {

                            if ((string)(row.Cells[3].Value) == tn.Parent.Parent.Text)
                            {
                                if ((string)(row.Cells[4].Value) == tn.Parent.Text.Substring(0, ProjectWorkbook.SelectedNode.Parent.Text.LastIndexOf(" (")))
                                {
                                    if ((string)(row.Cells[0].Value) == tn.Text)
                                    {
                                        UploadListing.Rows.RemoveAt(row.Index);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            try
            {
                ProjectWorkbook.SelectedNode.Parent.Text = ProjectWorkbook.SelectedNode.Parent.Text.Substring(0, ProjectWorkbook.SelectedNode.Parent.Text.LastIndexOf("(") + 1) + "0)";
                ProjectWorkbook.SelectedNode.Parent.Nodes.Clear();
            }
            catch (Exception exc)
            {

            }
        }
        private void UploadListing_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {

            foreach (TreeNode aNode in ProjectWorkbook.Nodes)
            {
                foreach (TreeNode bNode in aNode.Nodes)
                {
                    foreach (TreeNode cNode in bNode.Nodes)
                    {
                        foreach (TreeNode Node in cNode.Nodes)
                        {
                            if (Node.Text == e.Row.Cells[0].Value.ToString())
                            {

                                if (cNode.Text.Contains(e.Row.Cells[4].Value.ToString()) && bNode.Text.Contains(e.Row.Cells[3].Value.ToString()) && aNode.Text.Contains(e.Row.Cells[2].Value.ToString()))
                                {
                                    cNode.Text = cNode.Text.Substring(0, cNode.Text.LastIndexOf("(") + 1) + (int)(cNode.Nodes.Count - 1) + ")";
                                    cNode.Nodes.Remove(Node);
                                    return;
                                }
                            }
                        }
                    }
                }

            }
        }
        private void loadAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog FB = new OpenFileDialog();
            FB.Filter = "Configuration Files (*.xml)|*.xml|All files (*.*)|*.*";
            if (FB.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                Properties.Settings.Default.LocalWorkbooks = System.IO.File.ReadAllText(FB.FileName);
                Properties.Settings.Default.Save();
                UpdateWorkbook();
            }

        }

        private void WebBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            DocumentLoaded = true;
        }

        /// <summary>
        /// Click Event of ClearList Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            ClearList();
            //RemoveAll("From folder and upload list");
            MessageBox.Show("List Items cleared!", "Alert", MessageBoxButtons.OK);
        }

        private void ClearList()
        {

            int Filecount = 0;
            Boolean foundfile;


        checkuploadlist:
            foreach (DataGridViewRow row in UploadListing.Rows)
            {
                foreach (TreeNode tn in ProjectWorkbook.Nodes)
                {
                    ProjectWorkbook.SelectedNode = tn;
                    foundfile = false;
                    if ((string)(row.Cells[2].Value) == tn.Text)
                    {
                        foreach (TreeNode tn1 in tn.Nodes)
                        {
                            ProjectWorkbook.SelectedNode = tn1;
                            if ((string)(row.Cells[3].Value) == tn1.Text)
                            {
                                foreach (TreeNode tn2 in tn1.Nodes)
                                {
                                    ProjectWorkbook.SelectedNode = tn2;
                                    if ((string)(row.Cells[4].Value) == tn2.Text.Substring(0, tn2.Text.LastIndexOf(" (")))
                                    {
                                        foreach (TreeNode tn3 in tn2.Nodes)
                                        {
                                            ProjectWorkbook.SelectedNode = tn3;
                                            if ((string)(row.Cells[0].Value) == tn3.Text)
                                            {
                                                UploadListing.Rows.RemoveAt(row.Index);
                                                Filecount = Filecount + 1;
                                                foundfile = true;
                                                goto checkuploadlist;
                                            }
                                        }
                                        //                                        if (foundfile == true)
                                        //                                      {
                                        //                                        ProjectWorkbook.SelectedNode = tn2;
                                        //                                      ProjectWorkbook.SelectedNode.Text = ProjectWorkbook.SelectedNode.Text.Substring(0, ProjectWorkbook.SelectedNode.Text.LastIndexOf("(") + 1) + (int)(ProjectWorkbook.SelectedNode.Nodes.Count - 1) + ")";
                                        //                                    ProjectWorkbook.SelectedNode.Nodes.Clear();
                                        //                                  foundfile = false;
                                        //                                goto checkuploadlist;
                                        //}
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // remove from projectworkbook

            foreach (TreeNode tn in ProjectWorkbook.Nodes)
            {
                ProjectWorkbook.SelectedNode = tn;
                foreach (TreeNode tn1 in tn.Nodes)
                {
                    ProjectWorkbook.SelectedNode = tn1;
                    foreach (TreeNode tn2 in tn1.Nodes)
                    {
                        ProjectWorkbook.SelectedNode = tn2;
                        foreach (TreeNode tn3 in tn2.Nodes)
                        {
                            ProjectWorkbook.SelectedNode = tn3;
                            {
                                if (tn3 != null)
                                {
                                    ProjectWorkbook.SelectedNode = tn2;
                                    ProjectWorkbook.SelectedNode.Text = ProjectWorkbook.SelectedNode.Text.Substring(0, ProjectWorkbook.SelectedNode.Text.LastIndexOf("(") + 1) + "0)";
                                    ProjectWorkbook.SelectedNode.Nodes.Clear();
                                }
                            }
                        }
                    }
                }
            }

            ProjectWorkbook.SelectedNode = ProjectWorkbook.Nodes[0];
            UploadListing.Rows.Clear();
            CurrentRequestID.Text = "";
            FileSummary.Text = "";
            comboBox1.Text = "";
            InternalUseOnlyChkBox.Checked = false;
        }

    }

}