﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
namespace ALU_AUTO_Uploading
{
    public partial class HistoryViewer : Form
    {
        public HistoryViewer()
        {
            InitializeComponent();
        }

        private void HistoryViewer_Load(object sender, EventArgs e)
        {
            
            if (Properties.Settings.Default.UserHistory != "")
            {
                XmlDocument historyReader = new XmlDocument();
                historyReader.LoadXml(Properties.Settings.Default.UserHistory);
                int newRow = 0;
                foreach (XmlElement item in historyReader.DocumentElement.GetElementsByTagName("item"))
                {
                    newRow = HistoryGrid.Rows.Add();
                    HistoryGrid.Rows[newRow].Cells[0].Value = item.GetAttribute("Status");
                    HistoryGrid.Rows[newRow].Cells[1].Value = item.GetAttribute("Date");
                    HistoryGrid.Rows[newRow].Cells[2].Value = item.GetAttribute("RequestID");
                    HistoryGrid.Rows[newRow].Cells[3].Value = item.GetAttribute("WorkbookID");
                    HistoryGrid.Rows[newRow].Cells[4].Value = item.GetAttribute("CategorySection");
                    HistoryGrid.Rows[newRow].Cells[5].Value = item.GetAttribute("Section");
                    HistoryGrid.Rows[newRow].Cells[6].Value = item.GetAttribute("FileName");
                    HistoryGrid.Rows[newRow].Cells[8].Value = item.GetAttribute("LocalFilePath");
                    HistoryGrid.Rows[newRow].Cells[7].Value = item.GetAttribute("FileSummary");
                    HistoryGrid.Rows[newRow].Cells[9].Value = item.GetAttribute("State");
                    HistoryGrid.Rows[newRow].Cells[10].Value = item.GetAttribute("InternalUseOnly");
                }
            }
        }

        private void HistorySearch_TextChanged(object sender, EventArgs e)
        {
            //to be added
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.UserHistory = "<?xml version='1.0' encoding='utf-8'?><history></history>";
            Properties.Settings.Default.Save();
            HistoryGrid.Rows.Clear();
            MessageBox.Show("History cleared");
        }

        private void OpenHistory_Click(object sender, EventArgs e)
        {
            string tempPath = System.IO.Path.GetTempFileName();
            System.IO.File.WriteAllText(tempPath, Properties.Settings.Default.UserHistory);
            System.IO.File.Move(tempPath, tempPath.Replace(".tmp", ".xml"));
            //System.Diagnostics.Debug.Write(tempPath.Replace(".tmp", ".xml"));
            System.Diagnostics.Process.Start("EXCEL.exe", '"' + tempPath.Replace(".tmp", ".xml") + '"');
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                HistoryGrid.Rows.Clear();
                XmlDocument historyReader = new XmlDocument();
                //MessageBox.Show(Properties.Settings.Default.UserHistory);
                historyReader.LoadXml(Properties.Settings.Default.UserHistory);
                int newRow = 0;
                foreach (XmlElement item in historyReader.DocumentElement.GetElementsByTagName("item"))
                {
                    newRow = HistoryGrid.Rows.Add();
                    HistoryGrid.Rows[newRow].Cells[0].Value = item.GetAttribute("Status");
                    HistoryGrid.Rows[newRow].Cells[1].Value = item.GetAttribute("Date");
                    HistoryGrid.Rows[newRow].Cells[2].Value = item.GetAttribute("RequestID");
                    HistoryGrid.Rows[newRow].Cells[3].Value = item.GetAttribute("WorkbookID");
                    HistoryGrid.Rows[newRow].Cells[4].Value = item.GetAttribute("CategorySection");
                    HistoryGrid.Rows[newRow].Cells[5].Value = item.GetAttribute("Section");
                    HistoryGrid.Rows[newRow].Cells[6].Value = item.GetAttribute("FileName");
                    HistoryGrid.Rows[newRow].Cells[7].Value = item.GetAttribute("LocalFilePath");
                    HistoryGrid.Rows[newRow].Cells[8].Value = item.GetAttribute("FileSummary");
                    HistoryGrid.Rows[newRow].Cells[9].Value = item.GetAttribute("State");
                    HistoryGrid.Rows[newRow].Cells[10].Value = item.GetAttribute("InternalUseOnly");
                }
            }
            catch (Exception exc)
            {

            }
            
        }



        private void HistoryGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
