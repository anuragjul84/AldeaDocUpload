﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Drawing;

namespace ALU_AUTO_Uploading
{
    public class WinApiUser32
    {
        [DllImport("user32.dll", EntryPoint = "SetCursorPos")]
        public static extern int SetCursorPos(int x, int y);

        [DllImport("user32.dll", EntryPoint = "SendMessageA")]
        public static extern int SendMessage(IntPtr hwnd, int wMsg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll", EntryPoint = "SendMessageA")]
        public static extern bool PostMessage(IntPtr hwnd, int msg, uint wParam, uint lParam);

        [DllImport("user32.dll")]
        public static extern bool GetCursorPos(ref Point lpPoint);

        [DllImport("user32.dll")]
        public static extern IntPtr GetTopWindow(IntPtr hwnd);

        [DllImport("user32.dll")]
        public static extern IntPtr GetWindow(IntPtr hWnd, uint wCmd);

        [DllImport("user32.dll")]
        public static extern int GetForegroundWindow
        (

        );

        [DllImport("user32.dll")]
        public static extern int SendDlgltemMessage(IntPtr hDlg, int nlDDlgltem, uint Msg, string wParam, string IParam);

        /// <
        /// 
        /// >
        /// 根据句柄得到控件ID
        /// According to handle get to control ID
        /// </summary>
        /// <param name="hwndCtl"></param>
        /// <returns></returns>
        [DllImport("user32.dll")]
        public static extern int GetDlgCtrlID(IntPtr hwndCtl);
        /// <summary>
        /// 由控件ID获得控件窗口句柄
        ///  get the window handle by control ID
        /// </summary>
        /// <param name="hDlg"></param>
        /// <param name="nIDDlgItem"></param>
        /// <returns></returns>
        [DllImport("user32.dll ", EntryPoint = "GetDlgItem")]
        public static extern IntPtr GetDlgItem(
        IntPtr hDlg,
        int nIDDlgItem
        );
        /// <summary>
        ///  查找句柄
        ///  Find the handle
        /// </summary>
        /// <param name="lpClassName"></param>
        /// <param name="lpWindowName"></param>
        /// <returns></returns>
        [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        /// <summary>
        /// 查找句柄
        /// Find the handle
        /// </summary>
        /// <param name="hwndParent"></param>
        /// <param name="hwndChildAfter"></param>
        /// <param name="lpszClass">class name</param>
        /// <param name="lpszWindow">title</param>
        /// <returns></returns>
        [DllImport("user32.dll", EntryPoint = "FindWindowEx", SetLastError = true)]
        public static extern IntPtr FindWindowEx(IntPtr hwndParent, uint hwndChildAfter, string lpszClass, string lpszWindow);
        [DllImport("user32.dll")]
        public static extern int FindWindowEx(int hwndParent, int hwndChildAfter, string lpszClass, string lpszWindow);
        /// <summary>
        /// 发送消息
        /// Send a message
        /// </summary>
        /// <param name="hwnd"></param>
        /// <param name="wMsg"></param>
        /// <param name="wParam"></param>
        /// <param name="lParam"></param>
        /// <returns></returns>
        [DllImport("user32.dll", EntryPoint = "SendMessage", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern int SendMessage(IntPtr hwnd, uint wMsg, int wParam, int lParam);
        [DllImport("User32.dll")]
        public static extern int SendMessage(int hWnd, int Msg, int wParam, int lParam);

        [DllImport("user32.dll", EntryPoint = "SendMessageA")]
        public static extern int SendMessage(IntPtr hWnd, int wMsg, IntPtr wParam, string lParam);

        /// <summary>
        /// 发送文本消息
        /// Send text message
        /// </summary>
        /// <param name="hWnd"></param>
        /// <param name="Msg"></param>
        /// <param name="wParam"></param>
        /// <param name="lParam"></param>
        /// <returns></returns>
        [DllImport("User32.dll", EntryPoint = "SendMessage", CharSet = CharSet.Auto)]
        public static extern int SendTextMessage(
            IntPtr hWnd, // handle to destination window 
            int Msg, // message 
            int wParam, // first message parameter 
            string lParam
            // int  lParam // second message parameter 
        );
        /// <summary>
        /// 获取焦点
        /// get focus
        /// </summary>
        /// <param name="hwnd"></param>
        [DllImport("user32.dll", EntryPoint = "SetForegroundWindow", SetLastError = true)]
        public static extern void SetForegroundWindow(IntPtr hwnd);

        [DllImport("user32.dll")]
        public static extern int SetWindowText(int hwnd, string lpString);

        [DllImport("user32.dll")]
        public static extern int SetFocus(int hWnd);

        [DllImport("user32.dll")]
        public static extern int EnumChildWindows(int hWndParent, CallBack lpfn, int lParam);


        /// <summary>
        /// 回调业务
        /// The callback service
        /// </summary>
        public delegate void CallBusiness(IntPtr hwnd);
        public delegate bool CallBack(IntPtr hwnd, int lParam);
        /// <summary>
        /// 遍历子窗体的父窗体句柄
        /// Traversing the subform parent window handle
        /// </summary>
        public static CallBack callBackEnumChildWindows = new CallBack(ChildWindowProcess);
        /// <summary>
        /// 委托业务,需要客户端添加
        /// Commissioned by the business, the client needs to add
        /// </summary>
        public static CallBusiness CallFuntion;
        /// <summary>
        /// 遍历子窗体或控件
        /// Traversing the subform or control
        /// </summary>
        /// <param name="hWnd"></param>
        /// <param name="lParam"></param>
        /// <returns></returns>
        public static bool EnumChildWindows(IntPtr hWnd, int lParam)
        {
            EnumChildWindows(hWnd.ToInt32(), callBackEnumChildWindows, 0);
            return true;
        }
        /// <summary>
        /// 获取类名字
        /// get class name
        /// </summary>
        /// <param name="hwnd">需要获取类名的句柄 Handle to get the class name</param>
        /// <param name="lpClassName">类名(执行完成以后查看) The class name (execution completed view)</param>
        /// <param name="nMaxCount">缓冲区 Buffer</param>
        /// <returns></returns>
        [DllImport("user32.dll", EntryPoint = "GetClassName")]
        public static extern int GetClassName(
            IntPtr hwnd,
            StringBuilder lpClassName,
            int nMaxCount
        );
        /// <summary>
        /// 遍历子控件
        /// Traversing the child controls
        /// </summary>
        /// <param name="hwnd"></param>
        /// <param name="lParam"></param>
        /// <returns></returns>
        public static bool ChildWindowProcess(IntPtr hwnd, int lParam)
        {
            if (CallFuntion != null)
            {
                CallFuntion(hwnd);
            }
            return true;
        }
    }
}
